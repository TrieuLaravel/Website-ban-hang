-- MySQL dump 10.16  Distrib 10.2.18-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: qaixcyxdhosting_shopx
-- ------------------------------------------------------
-- Server version	10.2.18-MariaDB-log-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_admin`
--

DROP TABLE IF EXISTS `tbl_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_admin` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `role_id` int(11) NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `tbl_admin_username_unique` (`username`),
  UNIQUE KEY `tbl_admin_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_admin`
--

LOCK TABLES `tbl_admin` WRITE;
/*!40000 ALTER TABLE `tbl_admin` DISABLE KEYS */;
INSERT INTO `tbl_admin` (`id`, `username`, `name`, `email`, `email_verified_at`, `password`, `role_id`, `remember_token`, `status`, `created_at`, `updated_at`) VALUES (1,'Admin','Ivan Dương','dvnha0105@gmail.com','2019-07-21 17:00:00','$2y$10$zXP4kqpif8f78ozJh2h1Vu/dn4doJkAEditJugsrnU2ywlCiO3zDC',1,NULL,1,'2019-07-22 16:09:48','2019-07-22 16:09:48');
/*!40000 ALTER TABLE `tbl_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_analytics`
--

DROP TABLE IF EXISTS `tbl_analytics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_analytics` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `embeds` longtext COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_analytics`
--

LOCK TABLES `tbl_analytics` WRITE;
/*!40000 ALTER TABLE `tbl_analytics` DISABLE KEYS */;
INSERT INTO `tbl_analytics` (`id`, `name`, `embeds`, `status`, `created_at`, `updated_at`) VALUES (1,'Analytics','<!-- Global site tag (gtag.js) - Google Analytics -->\r\n<script async src=\"https://www.googletagmanager.com/gtag/js?id=UA-146130240-1\"></script>\r\n<script>\r\n  window.dataLayer = window.dataLayer || [];\r\n  function gtag(){dataLayer.push(arguments);}\r\n  gtag(\'js\', new Date());\r\n\r\n  gtag(\'config\', \'UA-146130240-1\');\r\n</script>',1,NULL,'2019-07-26 16:39:25');
/*!40000 ALTER TABLE `tbl_analytics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_binhluan`
--

DROP TABLE IF EXISTS `tbl_binhluan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_binhluan` (
  `ma_bl` int(11) NOT NULL AUTO_INCREMENT,
  `noidung_bl` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `ma_cha` int(11) DEFAULT NULL,
  `ma_sp` int(11) DEFAULT NULL,
  `ma_baiviet` int(11) DEFAULT NULL,
  `ma_kh` int(11) DEFAULT NULL,
  `trangthai` int(11) NOT NULL COMMENT '0:an;1:hien:-1:xoa',
  `ngaytao` datetime NOT NULL DEFAULT current_timestamp(),
  `ngay_update` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`ma_bl`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_binhluan`
--

LOCK TABLES `tbl_binhluan` WRITE;
/*!40000 ALTER TABLE `tbl_binhluan` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_binhluan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_chitietdonhang`
--

DROP TABLE IF EXISTS `tbl_chitietdonhang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_chitietdonhang` (
  `ma_dh` int(11) NOT NULL,
  `ma_sp` int(11) NOT NULL,
  `soluong` int(11) DEFAULT NULL,
  `dongia` float DEFAULT NULL,
  `giamgia` int(11) DEFAULT NULL,
  `donvitinh` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `trangthai` int(11) DEFAULT NULL COMMENT '0: an; 11: hien; -1: xoa',
  `ngaytao` datetime DEFAULT current_timestamp(),
  `ngay_update` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`ma_dh`,`ma_sp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_chitietdonhang`
--

LOCK TABLES `tbl_chitietdonhang` WRITE;
/*!40000 ALTER TABLE `tbl_chitietdonhang` DISABLE KEYS */;
INSERT INTO `tbl_chitietdonhang` (`ma_dh`, `ma_sp`, `soluong`, `dongia`, `giamgia`, `donvitinh`, `trangthai`, `ngaytao`, `ngay_update`) VALUES (1,6,3,98000,15,'cái',1,'2019-05-21 15:05:51','2019-05-21 15:05:51'),(1,10,2,270000,NULL,NULL,1,'2019-08-21 12:56:48','2019-08-21 12:56:48'),(1,15,1,5850000,NULL,NULL,1,'2019-08-21 12:56:48','2019-08-21 12:56:48'),(2,10,1,270000,NULL,NULL,1,'2019-08-31 15:50:02','2019-08-31 15:50:02'),(3,8,1,270000,NULL,NULL,1,'2019-08-31 15:56:15','2019-08-31 15:56:15'),(3,9,1,300000,NULL,NULL,1,'2019-08-31 15:56:15','2019-08-31 15:56:15'),(3,11,1,100000,NULL,NULL,1,'2019-08-31 15:56:15','2019-08-31 15:56:15'),(4,3,1,7500000,NULL,NULL,1,'2019-08-04 10:37:44','2019-08-04 10:37:44'),(4,6,2,98000,NULL,NULL,1,'2019-08-04 10:37:44','2019-08-04 10:37:44'),(4,7,1,10000,NULL,NULL,1,'2019-08-04 10:37:44','2019-08-04 10:37:44'),(4,10,2,270000,NULL,NULL,1,'2019-08-31 17:08:58','2019-08-31 17:08:58'),(5,3,1,7500000,NULL,NULL,1,'2019-08-04 10:44:06','2019-08-04 10:44:06'),(5,6,2,98000,NULL,NULL,1,'2019-08-04 10:44:06','2019-08-04 10:44:06'),(5,7,1,10000,NULL,NULL,1,'2019-08-04 10:44:06','2019-08-04 10:44:06'),(5,8,1,270000,NULL,NULL,1,'2019-08-31 17:19:45','2019-08-31 17:19:45'),(6,4,1,7500000,NULL,NULL,1,'2019-08-06 14:29:29','2019-08-06 14:29:29'),(6,8,1,270000,NULL,NULL,1,'2019-08-31 18:26:49','2019-08-31 18:26:49'),(7,4,1,7500000,NULL,NULL,1,'2019-08-06 14:30:40','2019-08-06 14:30:40'),(7,10,1,270000,NULL,NULL,1,'2019-08-31 18:27:37','2019-08-31 18:27:37'),(8,3,1,7500000,NULL,NULL,1,'2019-08-06 16:38:02','2019-08-06 16:38:02'),(8,9,1,300000,NULL,NULL,1,'2019-08-31 18:29:50','2019-08-31 18:29:50'),(9,3,1,7500000,NULL,NULL,1,'2019-08-06 16:39:28','2019-08-06 16:39:28'),(9,5,1,1960000,NULL,NULL,1,'2019-08-06 16:39:28','2019-08-06 16:39:28'),(9,11,1,100000,NULL,NULL,1,'2019-09-01 07:24:54','2019-09-01 07:24:54'),(10,5,1,1960000,NULL,NULL,1,'2019-08-10 17:54:54','2019-08-10 17:54:54'),(10,8,1,270000,NULL,NULL,1,'2019-09-01 15:39:24','2019-09-01 15:39:24'),(10,9,1,300000,NULL,NULL,1,'2019-09-01 15:39:24','2019-09-01 15:39:24'),(10,10,1,270000,NULL,NULL,1,'2019-09-01 15:39:24','2019-09-01 15:39:24'),(11,3,1,7500000,NULL,NULL,1,'2019-08-10 19:08:24','2019-08-10 19:08:24'),(11,10,1,270000,NULL,NULL,1,'2019-09-01 20:25:23','2019-09-01 20:25:23'),(11,11,1,100000,NULL,NULL,1,'2019-09-01 20:25:23','2019-09-01 20:25:23'),(11,12,1,50000,NULL,NULL,1,'2019-09-01 20:25:23','2019-09-01 20:25:23'),(12,5,5,1960000,NULL,NULL,1,'2019-08-13 15:14:29','2019-08-13 15:14:29'),(12,12,1,50000,NULL,NULL,1,'2019-09-02 03:30:52','2019-09-02 03:30:52'),(12,14,1,2695000,NULL,NULL,1,'2019-09-02 03:30:52','2019-09-02 03:30:52'),(13,11,1,100000,NULL,NULL,1,'2019-09-02 03:38:59','2019-09-02 03:38:59'),(13,14,1,2695000,NULL,NULL,1,'2019-09-02 03:38:59','2019-09-02 03:38:59'),(14,9,1,300000,NULL,NULL,1,'2019-09-02 03:41:15','2019-09-02 03:41:15'),(15,11,1,100000,NULL,NULL,1,'2019-09-02 03:44:19','2019-09-02 03:44:19'),(16,9,1,300000,NULL,NULL,1,'2019-09-02 03:45:49','2019-09-02 03:45:49'),(17,11,1,100000,NULL,NULL,1,'2019-09-02 03:48:01','2019-09-02 03:48:01'),(18,11,1,100000,NULL,NULL,1,'2019-09-02 03:51:20','2019-09-02 03:51:20'),(19,9,1,300000,NULL,NULL,1,'2019-09-02 03:57:41','2019-09-02 03:57:41'),(20,8,1,270000,NULL,NULL,1,'2019-09-02 04:04:06','2019-09-02 04:04:06'),(20,9,1,300000,NULL,NULL,1,'2019-09-02 04:04:06','2019-09-02 04:04:06'),(20,10,1,270000,NULL,NULL,1,'2019-09-02 04:04:06','2019-09-02 04:04:06'),(20,11,1,100000,NULL,NULL,1,'2019-09-02 04:04:06','2019-09-02 04:04:06'),(21,14,1,2695000,NULL,NULL,1,'2019-09-02 04:05:37','2019-09-02 04:05:37'),(22,11,1,100000,NULL,NULL,1,'2019-09-02 04:07:27','2019-09-02 04:07:27'),(23,15,1,5850000,NULL,NULL,1,'2019-09-02 04:09:53','2019-09-02 04:09:53');
/*!40000 ALTER TABLE `tbl_chitietdonhang` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_chucnang`
--

DROP TABLE IF EXISTS `tbl_chucnang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_chucnang` (
  `ma_chucnang` int(11) NOT NULL AUTO_INCREMENT,
  `ten_chucnang` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `icon` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lienket` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hienthimenu` int(11) DEFAULT NULL COMMENT '0: ẩn;1:hiện',
  `ma_cha` int(11) DEFAULT NULL,
  `action` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `controller` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `trangthai` int(11) DEFAULT NULL,
  `ngaytao` datetime DEFAULT current_timestamp(),
  `ngay_update` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`ma_chucnang`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_chucnang`
--

LOCK TABLES `tbl_chucnang` WRITE;
/*!40000 ALTER TABLE `tbl_chucnang` DISABLE KEYS */;
INSERT INTO `tbl_chucnang` (`ma_chucnang`, `ten_chucnang`, `icon`, `lienket`, `hienthimenu`, `ma_cha`, `action`, `controller`, `trangthai`, `ngaytao`, `ngay_update`) VALUES (1,'Tổng quan','<i class=\"fas fa-home\"></i>','index.php?controller=system&action=index',1,0,'index','system',1,'2019-06-21 20:51:24','2019-06-21 20:51:24'),(2,'Quản lý sản phẩm','<i class=\"far fa-credit-card\"></i>','#',1,0,NULL,NULL,1,'2019-06-19 15:19:14','2019-06-19 15:19:14'),(3,'Quản lý đơn hàng','<i class=\"fas fa-shopping-cart\"></i>','#',1,0,NULL,NULL,1,'2019-06-21 20:33:45','2019-06-21 20:33:45'),(4,'Quản ký khách hàng','<i class=\"fas fa-user\"></i>','#',1,0,NULL,NULL,1,'2019-06-21 20:45:33','2019-06-21 20:45:33'),(5,'Quản lý bài viết','<i class=\"fas fa-edit\"></i>','#',1,0,NULL,NULL,1,'2019-06-19 15:19:35','2019-06-19 15:19:35'),(6,'Quản lý quản trị','<i class=\"fas fa-users-cog\"></i>','#',1,0,NULL,NULL,1,'2019-06-19 15:20:12','2019-06-19 15:20:12'),(7,'Cấu hình website','<i class=\"fas fa-cogs\"></i>','#',1,0,NULL,NULL,1,'2019-06-19 15:20:31','2019-06-19 15:20:31'),(15,'Tất cả sản phẩm','<i class=\"fas fa-store-alt\"></i>','index.php?controller=sanpham&action=index',1,2,'index','sanpham',1,'2019-06-19 15:21:36','2019-06-19 15:21:36'),(24,'Thêm sản phẩm','<i class=\"fas fa-plus-circle\"></i>','index.php?controller=sanpham&action=create',0,15,'create','sanpham',1,'2019-06-19 15:22:27','2019-06-19 15:22:27'),(25,'Danh mục sản phẩm','<i class=\"fas fa-table\"></i>','index.php?controller=sanpham&action=categoryproduct',1,2,'categoryproduct','sanpham',1,'2019-06-19 15:24:17','2019-06-19 15:24:17'),(26,'Nhà cung cấp sản phẩm','<i class=\"fas fa-id-card\"></i>','index.php?controller=sanpham&action=nhacungcap',1,2,'nhacungcap','sanpham',1,'2019-06-19 15:25:00','2019-06-19 15:25:00'),(27,'Thương hiệu sản phẩm','<i class=\"far fa-copyright\"></i>','index.php?controller=sanpham&action=brand',1,2,'brand','sanpham',1,'2019-06-19 15:25:35','2019-06-19 15:25:35'),(28,'Tất cả bài viết','<i class=\"far fa-list-alt\"></i>','index.php?controller=content&action=loadbaiviet',1,5,'loadbaiviet','content',1,'2019-06-19 15:26:20','2019-06-19 15:26:20'),(29,'Danh mục bài viết','<i class=\"fas fa-table\"></i>','index.php?controller=content&action=loadcategory',1,5,'loadcategory','content',1,'2019-06-19 15:26:40','2019-06-19 15:26:40'),(30,'Bài viết đã xóa','<i class=\"fas fa-trash-alt\"></i>','#',0,5,NULL,NULL,1,'2019-06-19 15:26:58','2019-06-19 15:26:58'),(31,'Danh mục đã xóa','<i class=\"fas fa-trash-alt\"></i>','#',0,5,NULL,NULL,1,'2019-06-19 15:27:13','2019-06-19 15:27:13'),(32,'Quản lý user','<i class=\"fas fa-users\"></i>','index.php?controller=quantri&action=roles',1,6,'roles','quantri',1,'2019-06-19 15:28:22','2019-06-19 15:28:22'),(33,'Phân quyền user','<i class=\"fas fa-layer-group\"></i>','index.php?controller=quantri&action=permiss',1,6,'permiss','quantri',1,'2019-06-19 15:30:39','2019-06-19 15:30:39'),(34,'Cấu hình SEO','<i class=\"fas fa-cog\"></i>','#',1,7,NULL,NULL,1,'2019-06-19 15:31:16','2019-06-19 15:31:16'),(35,'Ghi quyền','<i class=\"fas fa-user-plus\"></i>','index.php?controller=quantri&action=grant',0,6,'grant','quantri',1,'2019-06-19 15:31:16','2019-06-19 15:31:16'),(37,'Nhóm quản trị','<i class=\"fas fa-users-cog\"></i>','#',1,6,'groupuser','quantri',1,'2019-06-21 11:30:55','2019-06-21 11:30:55'),(39,'Danh sách đơn hàng','<i class=\"far fa-list-alt\"></i>','index.php?controller=order&action=index',1,3,'index','order',1,'2019-06-21 20:40:41','2019-06-21 20:40:41'),(40,'Thống kê','<i class=\"fas fa-chart-line\"></i>','index.php?controller=order&action=statistics',1,3,'statistics','order',1,'2019-06-21 20:42:07','2019-06-21 20:42:07'),(42,'Danh sách khách hàng','<i class=\"far fa-list-alt\"></i>','index.php?controller=customer&action=index',1,4,'index','customer',1,'2019-06-21 20:47:57','2019-06-21 20:47:57'),(45,'Sửa sản phẩm','<i class=\"far fa-edit\"></i>','index.php?controller=sanpham&action=editsp',0,15,'editsp','sanpham',1,'2019-06-21 22:00:06','2019-06-21 22:00:06'),(46,'Xóa sản phẩm','<i class=\"fas fa-trash\"></i>','index.php?controller=sanpham&action=deletesp',0,15,'deletesp','sanpham',1,'2019-06-21 22:04:57','2019-06-21 22:04:57'),(47,'Thêm danh mục','<i class=\"far fa-plus-square\"></i>','index.php?controller=sanpham&action=create_cate',0,25,'create_cate','sanpham',1,'2019-06-21 22:09:20','2019-06-21 22:09:20'),(48,'Sửa danh mục','<i class=\"fas fa-edit\"></i>','index.php?controller=sanpham&action=editcate',0,25,'editcate','sanpham',1,'2019-06-21 22:11:38','2019-06-21 22:11:38'),(49,'Xóa danh mục','<i class=\"fas fa-trash\"></i>','index.php?controller=sanpham&action=deletecate',0,25,'deletecate','sanpham',1,'2019-06-21 22:11:44','2019-06-21 22:11:44'),(50,'Thêm nhà cung cấp','<i class=\"fas fa-plus-square\"></i>','index.php?controller=sanpham&action=create_ncc',0,26,'create_ncc','sanpham',1,'2019-06-21 22:13:42','2019-06-21 22:13:42'),(51,'Sửa nhà cung cấp','<i class=\"fas fa-edit\"></i>','index.php?controller=sanpham&action=editncc',0,26,'editncc','sanpham',1,'2019-06-21 22:15:25','2019-06-21 22:15:25'),(52,'Xóa nhà cung cấp','<i class=\"fas fa-trash\"></i>','index.php?controller=sanpham&action=deletencc',0,26,'deletencc','sanpham',1,'2019-06-21 22:16:29','2019-06-21 22:16:29'),(53,'Thêm thương hiệu','<i class=\"fas fa-plus-square\"></i>','index.php?controller=sanpham&action=create_brand',0,27,'create_brand','sanpham',1,'2019-06-21 22:17:47','2019-06-21 22:17:47'),(54,'Sửa thương hiệu','<i class=\"fas fa-edit\"></i>','index.php?controller=sanpham&action=editbrand',0,27,'editbrand','sanpham',1,'2019-06-21 22:17:47','2019-06-21 22:17:47'),(55,'Xóa thương hiệu','<i class=\"fas fa-trash\"></i>','index.php?controller=sanpham&action=deletebrand',0,27,'deletebrand','sanpham',1,'2019-06-21 22:20:16','2019-06-21 22:20:16'),(56,'Thêm bài viết','<i class=\"fas fa-plus-square\"></i>','index.php?controller=content&action=create_baiviet',0,28,'create_baiviet','content',1,'2019-06-21 22:22:00','2019-06-21 22:22:00'),(57,'Sửa bài viết','<i class=\"fas fa-edit\"></i>','index.php?controller=content&action=editbaiviet',0,28,'editbaiviet','content',1,'2019-06-21 22:23:46','2019-06-21 22:23:46'),(58,'Xóa bài viết','<i class=\"fas fa-trash\"></i>','index.php?controller=content&action=deletebaiviet',0,28,'deletebaiviet','content',1,'2019-06-21 22:24:43','2019-06-21 22:24:43'),(59,'Thêm danh mục','<i class=\"fas fa-plus-square\"></i>','index.php?controller=content&action=create_category',0,29,'create_category','content',1,'2019-06-21 22:25:38','2019-06-21 22:25:38'),(60,'Sửa danh mục','<i class=\"fas fa-edit\"></i>','index.php?controller=content&action=editcategory',0,29,'editcategory','content',1,'2019-06-21 22:26:55','2019-06-21 22:26:55'),(61,'Xóa danh mục','<i class=\"fas fa-trash\"></i>','index.php?controller=content&action=deletecategory',0,29,'deletecategory','content',1,'2019-06-21 22:27:40','2019-06-21 22:27:40'),(62,'Thêm user','<i class=\"fas fa-user-plus\"></i>','index.php?controller=quantri&action=create_user',0,32,'create_user','quantri',1,'2019-06-21 22:29:57','2019-06-21 22:29:57'),(63,'Sửa user','<i class=\"fas fa-edit\"></i>','index.php?controller=quantri&action=edituser',0,32,'edituser','quantri',1,'2019-06-21 22:32:56','2019-06-21 22:32:56'),(64,'Xóa user','<i class=\"fas fa-trash\"></i>','index.php?controller=quantri&action=deleteuser',0,32,'deleteuser','quantri',1,'2019-06-21 22:33:56','2019-06-21 22:33:56'),(65,'Thêm nhóm quản trị','<i class=\"fas fa-plus-square\"></i>','index.php?controller=quantri&action=create_groupuser',0,37,'create_groupuser','quantri',1,'2019-06-21 22:34:50','2019-06-21 22:34:50'),(66,'Sửa nhóm quản trị','<i class=\"fas fa-edit\"></i>','index.php?controller=quantri&action=editgroup',0,37,'editgroup','quantri',1,'2019-06-21 22:36:51','2019-06-21 22:36:51'),(67,'Xóa nhóm quản trị','<i class=\"fas fa-trash\"></i>','index.php?controller=quantri&action=deletegroup',0,37,'deletegroup','quantri',1,'2019-06-21 22:37:44','2019-06-21 22:37:44'),(68,'Thêm đơn hàng','<i class=\"fas fa-plus-square\"></i>','index.php?controller=order&action=create_order',0,39,'create_order','order',1,'2019-06-21 22:39:12','2019-06-21 22:39:12'),(69,'Sửa đơn hàng','<i class=\"fas fa-edit\"></i>','index.php?controller=order&action=editorder',0,39,'editorder','order',1,'2019-06-21 22:40:48','2019-06-21 22:40:48'),(70,'Xóa đơn hàng','<i class=\"fas fa-trash\"></i>','index.php?controller=order&action=deleteorder',0,39,'deleteorder','order',1,'2019-06-21 22:41:34','2019-06-21 22:41:34'),(71,'Sửa khách hàng','<i class=\"fas fa-edit\"></i>','index.php?controller=customer&action=editcustomer',0,42,'editcustomer','customer',1,'2019-06-21 22:42:45','2019-06-21 22:42:45'),(72,'Xóa khách hàng','<i class=\"fas fa-trash\"></i>','index.php?controller=customer&action=deletecustomer',0,42,'deletecustomer','customer',1,'2019-06-21 22:44:34','2019-06-21 22:44:34');
/*!40000 ALTER TABLE `tbl_chucnang` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_danhgia`
--

DROP TABLE IF EXISTS `tbl_danhgia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_danhgia` (
  `ma_dg` int(11) NOT NULL AUTO_INCREMENT,
  `noidung_dg` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `so_sao` int(11) DEFAULT NULL,
  `ma_sp` int(11) DEFAULT NULL,
  `ma_baiviet` int(11) DEFAULT NULL,
  `trangthai` int(11) NOT NULL COMMENT '0:an;1:hien:-1:xoa',
  `ngaytao` datetime NOT NULL DEFAULT current_timestamp(),
  `ngaay_update` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`ma_dg`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_danhgia`
--

LOCK TABLES `tbl_danhgia` WRITE;
/*!40000 ALTER TABLE `tbl_danhgia` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_danhgia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_donhang`
--

DROP TABLE IF EXISTS `tbl_donhang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_donhang` (
  `ma_dh` int(11) NOT NULL AUTO_INCREMENT,
  `ma_kh` int(11) DEFAULT NULL,
  `ngaydat` datetime DEFAULT current_timestamp(),
  `so_dh` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phi_vc_dh` float DEFAULT NULL,
  `tongtien_dh` float DEFAULT NULL,
  `trangthai_dh` int(11) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `note` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `trangthai` int(11) DEFAULT NULL COMMENT '0:an;1:hien;-1:xoa',
  `ngay_tao` datetime DEFAULT current_timestamp(),
  `ngay_update` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`ma_dh`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_donhang`
--

LOCK TABLES `tbl_donhang` WRITE;
/*!40000 ALTER TABLE `tbl_donhang` DISABLE KEYS */;
INSERT INTO `tbl_donhang` (`ma_dh`, `ma_kh`, `ngaydat`, `so_dh`, `phi_vc_dh`, `tongtien_dh`, `trangthai_dh`, `type`, `note`, `trangthai`, `ngay_tao`, `ngay_update`) VALUES (20,43,'2019-09-02 04:04:06','1567397046',0,940000,0,0,'giao hang nhanh',1,'2019-09-02 04:04:06','2019-09-02 04:04:06'),(21,44,'2019-09-02 04:05:37','1567397137',0,2695000,1,0,'giao hàng nhanh',1,'2019-09-02 04:05:37','2019-09-02 04:05:37'),(22,45,'2019-09-02 04:07:27','1567397247',0,100000,0,0,'giao hàng thứ 4',1,'2019-09-02 04:07:27','2019-09-02 04:07:27'),(23,46,'2019-09-02 04:09:53','1567397393',0,5850000,-1,1,'giao hang hanh chinh',1,'2019-09-02 04:09:53','2019-09-02 04:09:53');
/*!40000 ALTER TABLE `tbl_donhang` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_khachhang`
--

DROP TABLE IF EXISTS `tbl_khachhang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_khachhang` (
  `ma_kh` int(11) NOT NULL AUTO_INCREMENT,
  `ten_kh` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dienthoai_kh` int(11) DEFAULT NULL,
  `email_kh` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `diachi_kh` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `trangthai_kh` int(11) DEFAULT NULL COMMENT '0: aan; 1:hien;-1:xoa',
  `ngaytao_kh` datetime DEFAULT current_timestamp(),
  `ngay_update_kh` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`ma_kh`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_khachhang`
--

LOCK TABLES `tbl_khachhang` WRITE;
/*!40000 ALTER TABLE `tbl_khachhang` DISABLE KEYS */;
INSERT INTO `tbl_khachhang` (`ma_kh`, `ten_kh`, `dienthoai_kh`, `email_kh`, `diachi_kh`, `trangthai_kh`, `ngaytao_kh`, `ngay_update_kh`) VALUES (19,'Duong Van Nha',234567895,'dvnha0105@gmail.com','Cu chi Tp.HCM',1,'2019-08-06 16:38:02','2019-08-06 16:38:02'),(20,'Duong Van Nha',234567895,'dvnha0105@gmail.com','Cu chi Tp.HCM',1,'2019-08-06 16:39:28','2019-08-06 16:39:28'),(21,'Thu Huyền',987654321,'huyenstore@gmail.com','Cu chi, tp ho chi minh',1,'2019-08-10 17:54:54','2019-08-10 17:54:54'),(22,'Thu Huyền',987654321,'huyenstore@gmail.com','Cu chi, tp ho chi minh',1,'2019-08-10 19:08:24','2019-08-10 19:08:24'),(23,'Thu Huyền',987654321,'huyenstore@gmail.com','Cu chi, tp ho chi minh',1,'2019-08-13 15:14:29','2019-08-13 15:14:29'),(24,'nguyen phuoc loc',351234567,'nguyenphuocloc15@gmail.com','duong ha huy giap, quan 12',1,'2019-08-21 12:56:48','2019-08-21 12:56:48'),(25,'Duong van nha',987654321,'duongnha0105@gmail.com','Cu chi, tp ho chi minh',1,'2019-08-31 15:50:02','2019-08-31 15:50:02'),(26,'Thu Huyền',987654321,'huyenstore@gmail.com','Cu chi, tp ho chi minh',1,'2019-08-31 15:56:15','2019-08-31 15:56:15'),(27,'Thu Huyền',987654321,'duongnha0105@gmail.com','Cu chi, tp ho chi minh',1,'2019-08-31 17:08:58','2019-08-31 17:08:58'),(28,'Duong van nha',987654321,'duongnha0105@gmail.com','Cu chi, tp ho chi minh',1,'2019-08-31 17:19:45','2019-08-31 17:19:45'),(29,'Thu Huyền',987654321,'duongnha0105@gmail.com','Cu chi, tp ho chi minh',1,'2019-08-31 18:26:49','2019-08-31 18:26:49'),(30,'Thu Huyền',987654321,'duongnha0105@gmail.com','Cu chi, tp ho chi minh',1,'2019-08-31 18:27:37','2019-08-31 18:27:37'),(31,'Thu Huyền',987654321,'duongnha0105@gmail.com','Cu chi, tp ho chi minh',1,'2019-08-31 18:29:49','2019-08-31 18:29:49'),(32,'nguyen hung',352345987,'hung@gmail','ha huy giap q12',1,'2019-09-01 07:24:54','2019-09-01 07:24:54'),(33,'Dương văn nhã',966487384,'dvnha0105@gmail.com','Củ chi, Tp.hcm',1,'2019-09-01 15:39:24','2019-09-01 15:39:24'),(34,'Thu Huyền',987654321,'duongnha0105@gmail.com','Cu chi, tp ho chi minh',1,'2019-09-01 20:25:23','2019-09-01 20:25:23'),(35,'Duong van nha',987654321,'huyenstore@gmail.com','Cu chi, tp ho chi minh',1,'2019-09-02 03:30:52','2019-09-02 03:30:52'),(36,'Duong van nha',987654321,'dvnha0999@gmail.com','Cu chi, tp ho chi minh',1,'2019-09-02 03:38:59','2019-09-02 03:38:59'),(37,'Thu Huyền',987654321,'duongnha0105@gmail.com','Cu chi, tp ho chi minh',1,'2019-09-02 03:41:15','2019-09-02 03:41:15'),(38,'Thu Huyền',987654321,'duongnha0105@gmail.com','Cu chi, tp ho chi minh',1,'2019-09-02 03:44:19','2019-09-02 03:44:19'),(39,'Thu Huyền',987654321,'duongnha0105@gmail.com','Cu chi, tp ho chi minh',1,'2019-09-02 03:45:49','2019-09-02 03:45:49'),(40,'Thu Huyền',987654321,'duongnha0105@gmail.com','Cu chi, tp ho chi minh',1,'2019-09-02 03:48:01','2019-09-02 03:48:01'),(41,'Thu Huyền',987654321,'duongnha0105@gmail.com','Cu chi, tp ho chi minh',1,'2019-09-02 03:51:20','2019-09-02 03:51:20'),(42,'Thu Huyền',987654321,'duongnha0105@gmail.com','Cu chi, tp ho chi minh',1,'2019-09-02 03:57:41','2019-09-02 03:57:41'),(43,'Duong van nha',987654321,'duongnha0105@gmail.com','Cu chi, tp ho chi minh',1,'2019-09-02 04:04:06','2019-09-02 04:04:06'),(44,'Thu Huyền',966487384,'dvnha0999@gmail.com','Cầu Giấy, Hà Nội',1,'2019-09-02 04:05:37','2019-09-02 04:05:37'),(45,'Dương Đỗ Phú Gia',962172329,'phugia2312@gmail.com','Thuận thành, Bắc ninh',1,'2019-09-02 04:07:27','2019-09-02 04:07:27'),(46,'Phú Gia',966745875,'phugia@2018.com','Cu chi, tp ho chi minh',1,'2019-09-02 04:09:53','2019-09-02 04:09:53');
/*!40000 ALTER TABLE `tbl_khachhang` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_langues`
--

DROP TABLE IF EXISTS `tbl_langues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_langues` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `icon` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_langues`
--

LOCK TABLES `tbl_langues` WRITE;
/*!40000 ALTER TABLE `tbl_langues` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_langues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_loaisp`
--

DROP TABLE IF EXISTS `tbl_loaisp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_loaisp` (
  `ma_loai` int(11) NOT NULL AUTO_INCREMENT,
  `ten_loai_sp` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mota_loai_sp` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hinh_loai_sp` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ma_cha` int(11) DEFAULT NULL,
  `tieude_loai_sp` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tukhoa_loai_sp` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mota_seo_loai_sp` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hinh_share_loai_sp` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `link_alias_loai_sp` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `trangthai_loai_sp` int(11) DEFAULT NULL COMMENT '0: an; 1:hien;-1:xoa',
  `ngaytao_loai_sp` datetime DEFAULT current_timestamp(),
  `update_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`ma_loai`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_loaisp`
--

LOCK TABLES `tbl_loaisp` WRITE;
/*!40000 ALTER TABLE `tbl_loaisp` DISABLE KEYS */;
INSERT INTO `tbl_loaisp` (`ma_loai`, `ten_loai_sp`, `mota_loai_sp`, `hinh_loai_sp`, `ma_cha`, `tieude_loai_sp`, `tukhoa_loai_sp`, `mota_seo_loai_sp`, `hinh_share_loai_sp`, `link_alias_loai_sp`, `trangthai_loai_sp`, `ngaytao_loai_sp`, `update_at`) VALUES (1,'Thời trang nữ','Thời trang dành cho nữ','https://vn-test-11.slatic.net/skyline/i8/12f3bc98560f4eaa948a20b33c5ac5a0-1360-480.jpg_desktop.jpg',1,'Thời trang nữ','thời trang nữ, thoi trang nu','Thời trang nữ','https://vn-test-11.slatic.net/skyline/i8/12f3bc98560f4eaa948a20b33c5ac5a0-1360-480.jpg_desktop.jpg','thoi-trang-nu',1,'2019-05-17 22:42:41','2019-05-17 22:42:41'),(2,'Thời trang nam','Thời trang dành cho nam','https://vn-test-11.slatic.net/skyline/i8/12f3bc98560f4eaa948a20b33c5ac5a0-1360-480.jpg_desktop.jpg',2,'Thời trang nam','Thời trang nam, thoi trang nam','Thời trang nam','https://vn-test-11.slatic.net/skyline/i8/12f3bc98560f4eaa948a20b33c5ac5a0-1360-480.jpg_desktop.jpg','thoi-trang-nam',1,'2019-05-17 22:42:41','2019-05-17 22:42:41'),(6,'Phụ kiện thời trang',NULL,'https://shopxinh.com.vn/public/upload/images/qu.jpg',0,'Phụ kiện thời trang','Phụ kiện thời trang','Phụ kiện thời trang',NULL,'phu-kien-thoi-trang',1,'2019-08-19 21:34:41','2019-08-19 21:34:41');
/*!40000 ALTER TABLE `tbl_loaisp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_menu`
--

DROP TABLE IF EXISTS `tbl_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_menu` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `locations` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_menu`
--

LOCK TABLES `tbl_menu` WRITE;
/*!40000 ALTER TABLE `tbl_menu` DISABLE KEYS */;
INSERT INTO `tbl_menu` (`id`, `name`, `url`, `parent_id`, `locations`, `status`, `created_at`, `updated_at`) VALUES (1,'Trang chủ','/',0,0,1,'2019-08-20 16:40:35','2019-08-20 16:40:35'),(2,'Giới thiệu','/gioi-thieu',0,1,1,'2019-08-20 16:40:59','2019-08-20 16:40:59'),(3,'Sản phẩm','/san-pham',0,2,1,'2019-08-20 16:41:21','2019-08-20 16:41:21');
/*!40000 ALTER TABLE `tbl_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_migrations`
--

DROP TABLE IF EXISTS `tbl_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_migrations`
--

LOCK TABLES `tbl_migrations` WRITE;
/*!40000 ALTER TABLE `tbl_migrations` DISABLE KEYS */;
INSERT INTO `tbl_migrations` (`id`, `migration`, `batch`) VALUES (3,'2019_07_06_170223_admin_users',1),(8,'2014_10_12_000000_create_users_table',2),(9,'2014_10_12_100000_create_password_resets_table',2),(10,'2019_07_12_154120_create_pages_table',2),(11,'2019_07_16_151532_create_slide_table',2),(12,'2019_07_19_161439_create_roles_table',2),(13,'2019_07_20_142731_create_role_user_table',2),(14,'2019_07_22_154931_create_admin_table',3),(15,'2019_07_23_061908_create_permissions_table',4),(16,'2019_07_24_111151_create_permissions_table',5),(17,'2019_07_24_122106_create_permissions_table',6),(18,'2019_07_24_122302_create_permissions_table',7),(19,'2019_07_25_162809_create_setting_table',8),(20,'2019_07_28_093130_create_roles_permissions_table',9),(21,'2019_08_14_104527_create_menu_table',10),(22,'2019_08_14_104701_create_quangcao_table',10);
/*!40000 ALTER TABLE `tbl_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_nhacungcap`
--

DROP TABLE IF EXISTS `tbl_nhacungcap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_nhacungcap` (
  `ma_ncc` int(11) NOT NULL AUTO_INCREMENT,
  `ten_ncc` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `diachi_ncc` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sodienthoai` int(11) DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `trangthai` int(11) DEFAULT NULL COMMENT '0: an, 1: hien, -1:xoa',
  `ngaytao` datetime DEFAULT current_timestamp(),
  `ngaycapnhat` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`ma_ncc`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_nhacungcap`
--

LOCK TABLES `tbl_nhacungcap` WRITE;
/*!40000 ALTER TABLE `tbl_nhacungcap` DISABLE KEYS */;
INSERT INTO `tbl_nhacungcap` (`ma_ncc`, `ten_ncc`, `diachi_ncc`, `sodienthoai`, `email`, `trangthai`, `ngaytao`, `ngaycapnhat`) VALUES (6,'Blue Store','Hà Nội',123569878,'bluestore@gmail.com',0,'2019-05-21 14:22:09','2019-05-21 14:22:09'),(7,'Thái Tuấn',NULL,966487384,NULL,1,'2019-08-19 22:37:47','2019-08-19 22:37:47'),(8,'Shopgiasi',NULL,962172329,NULL,1,'2019-08-19 22:37:54','2019-08-19 22:37:54'),(9,'Shop Online',NULL,908778845,NULL,1,'2019-08-19 22:38:01','2019-08-19 22:38:01');
/*!40000 ALTER TABLE `tbl_nhacungcap` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_nhomquantri`
--

DROP TABLE IF EXISTS `tbl_nhomquantri`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_nhomquantri` (
  `manhom` int(11) NOT NULL AUTO_INCREMENT,
  `tennhom` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mota` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `trangthai` int(11) DEFAULT NULL COMMENT '0:An;1:hien:-1: Xoa',
  `ngaytao` datetime DEFAULT current_timestamp(),
  `ngay_update` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`manhom`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_nhomquantri`
--

LOCK TABLES `tbl_nhomquantri` WRITE;
/*!40000 ALTER TABLE `tbl_nhomquantri` DISABLE KEYS */;
INSERT INTO `tbl_nhomquantri` (`manhom`, `tennhom`, `mota`, `trangthai`, `ngaytao`, `ngay_update`) VALUES (1,'Quản trị','Quản trị website',1,'2019-05-22 18:12:23','2019-05-22 18:12:23'),(2,'Quản trị sản phẩm','Quản trị sản phẩm',1,'2019-05-22 18:12:42','2019-05-22 18:12:42'),(3,'Quản trị nội dung','Quản trị nội dung',1,'2019-05-22 18:13:02','2019-05-22 18:13:02');
/*!40000 ALTER TABLE `tbl_nhomquantri` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_nhomtin`
--

DROP TABLE IF EXISTS `tbl_nhomtin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_nhomtin` (
  `ma_nhomtin` int(11) NOT NULL AUTO_INCREMENT,
  `ten_nhomtin` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mota_nhomtin` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `icon_nhomtin` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tieude_seo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mota_seo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `linkhinh_share` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nhomtin_alias` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tukhoa_seo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `trangthai` int(11) DEFAULT NULL COMMENT '0:an;1:hien;-1:xoa',
  `ngaytao` datetime DEFAULT current_timestamp(),
  `ngay_update` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`ma_nhomtin`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_nhomtin`
--

LOCK TABLES `tbl_nhomtin` WRITE;
/*!40000 ALTER TABLE `tbl_nhomtin` DISABLE KEYS */;
INSERT INTO `tbl_nhomtin` (`ma_nhomtin`, `ten_nhomtin`, `mota_nhomtin`, `icon_nhomtin`, `tieude_seo`, `mota_seo`, `linkhinh_share`, `nhomtin_alias`, `tukhoa_seo`, `trangthai`, `ngaytao`, `ngay_update`) VALUES (1,'Tin tức thời trang','Tin tức thời trang',NULL,'Tin tức thời trang','Tin tức thời trang',NULL,'tin-tuc-thoi-trang','Tin tức thời trang',1,'2019-05-21 15:07:34','2019-05-21 15:07:34'),(4,'Tin thời trang quốc tế','Tin thời trang quốc tế',NULL,'Tin thời trang quốc tế','Tin thời trang quốc tế',NULL,'tin-thoi-trang-quoc-tê','Tin thời trang quốc tế',1,'2019-05-21 15:09:11','2019-05-21 15:09:11');
/*!40000 ALTER TABLE `tbl_nhomtin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_pages`
--

DROP TABLE IF EXISTS `tbl_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_pages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `contents` longtext COLLATE utf8_unicode_ci NOT NULL,
  `titleseo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `keyword` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `descriptions` longtext COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_pages`
--

LOCK TABLES `tbl_pages` WRITE;
/*!40000 ALTER TABLE `tbl_pages` DISABLE KEYS */;
INSERT INTO `tbl_pages` (`id`, `title`, `alias`, `image`, `contents`, `titleseo`, `keyword`, `descriptions`, `status`, `created_at`, `updated_at`) VALUES (1,'Trang giới thiệu','trang-gioi-thieu','http://localhost/doanlaravelbanhang/public/upload/images/logo.png','<strong>SHOPXINH</strong> là thành viên của <strong>NouStore</strong>, là cầu nối tin cậy giữa người mua sỉ và người bán sỉ. Shopxinh.com.vn hướng tới việc xây dựng một cộng đồng mua bán sỉ uy tín, chất lượng, nguồn hàng sỉ đa dạng phong phú đủ các thể loại thời trang, giày dép & túi xách, đồng hồ & phụ kiện, sản phẩm trẻ em, làm đẹp sức khỏe, phụ kiện hitech, dụng cụ bảo hộ, vải vóc, phụ liệu....<br />\r\n<br />\r\n<strong>SHOPXINH</strong> chính thức ra đời từ tháng 1/2018 với mục tiêu trở thành cổng kết nối online lớn nhất Việt Nam giữa các nhà bán buôn/bán sỉ với khách hàng sỉ trên toàn quốc.<br />\r\n<br />\r\nVới nền công nghệ mới nhất hiện nay <strong>SHOPXINH </strong>cung cấp miễn phí cho mỗi người mua sỉ, tham gia cộng tác bán sỉ cùng ShopXinh một Website chuyên nghiệp sử dụng tên miền riêng, xây dựng thương hiệu cá nhân hóa cho từng người. Đồng thời cung cấp cho Nhà sản xuất, nhà phân phối một hệ thống công nghệ có thể tạo ra một chợ Online cho riêng mình, tạo ra hàng nghìn Website nhân viên bán buôn, CTV bán buôn tiếp thị liên kết với chi phí rất thấp.<br />\r\n<br />\r\nChúng tôi là đối tác phân phối cho các thương hiệu Việt Nam uy tín như : Vinabrands,KimLong,Milkey Dress,Teknail.... Càng đáng tin cậy hơn, khi chúng tôi được đầu tư bởi NouStore, Là đơn vị cung cấp nền tảng công nghệ kết nối chia sẻ duy nhất và đầu tiên tại Việt Nam<br />\r\n<br />\r\n<strong>Mục tiêu </strong><br />\r\n<br />\r\n<strong>“SHOPXINH\"</strong> mong muốn đem lại cho người mua sỉ có nguồn hàng tốt và nhà sản xuất có được giải pháp kinh doanh Online bền vững với chi phí thấp, hiệu quả cao. Mua bán sỉ Online là nhớ đến ShopXinh cổng kết nối giao thương bán sỉ lớn nhất Việt Nam.<br />\r\n<br />\r\n<strong>Tầm nhìn và sứ mệnh</strong><br />\r\n<br />\r\n\"Mỗi cá nhân mua bán sỉ được sở hữu miễn phí Website thông minh là công cụ kết nối nguồn hàng từ các nhà sản xuất uy tín, chất lượng trên toàn quốc. Ngồi tại nhà mua sỉ tận xưởng, bán sỉ không cần nhập hàng, không bỏ vốn, không tồn kho, không rủi ro tài chính\"','Trang giới thiệu','Trang giới thiệu, shopxinh, shop thời trang','Trang giới thiệu',1,'2019-08-10 23:04:12','2019-08-10 16:46:49');
/*!40000 ALTER TABLE `tbl_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_password_resets`
--

DROP TABLE IF EXISTS `tbl_password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `tbl_password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_password_resets`
--

LOCK TABLES `tbl_password_resets` WRITE;
/*!40000 ALTER TABLE `tbl_password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_permissions`
--

DROP TABLE IF EXISTS `tbl_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `icon` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `display_menu` int(11) DEFAULT NULL,
  `display` int(11) DEFAULT NULL,
  `id_parent` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `tbl_permissions_name_unique` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_permissions`
--

LOCK TABLES `tbl_permissions` WRITE;
/*!40000 ALTER TABLE `tbl_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_phanquyen`
--

DROP TABLE IF EXISTS `tbl_phanquyen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_phanquyen` (
  `ma_pq` int(11) NOT NULL AUTO_INCREMENT,
  `ma_chucnang` int(11) DEFAULT NULL,
  `ma` int(11) DEFAULT NULL,
  `trangthai` int(11) DEFAULT NULL,
  `ngaytao` datetime DEFAULT current_timestamp(),
  `ngay_update` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`ma_pq`)
) ENGINE=InnoDB AUTO_INCREMENT=1762 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_phanquyen`
--

LOCK TABLES `tbl_phanquyen` WRITE;
/*!40000 ALTER TABLE `tbl_phanquyen` DISABLE KEYS */;
INSERT INTO `tbl_phanquyen` (`ma_pq`, `ma_chucnang`, `ma`, `trangthai`, `ngaytao`, `ngay_update`) VALUES (1427,1,3,NULL,'2019-06-19 18:20:11','2019-06-19 18:20:11'),(1428,5,3,NULL,'2019-06-19 18:20:11','2019-06-19 18:20:11'),(1429,24,3,NULL,'2019-06-19 18:20:12','2019-06-19 18:20:12'),(1430,25,3,NULL,'2019-06-19 18:20:12','2019-06-19 18:20:12'),(1431,26,3,NULL,'2019-06-19 18:20:12','2019-06-19 18:20:12'),(1432,27,3,NULL,'2019-06-19 18:20:12','2019-06-19 18:20:12'),(1710,1,1,NULL,'2019-06-21 22:46:32','2019-06-21 22:46:32'),(1711,2,1,NULL,'2019-06-21 22:46:32','2019-06-21 22:46:32'),(1712,15,1,NULL,'2019-06-21 22:46:32','2019-06-21 22:46:32'),(1713,24,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33'),(1714,45,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33'),(1715,46,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33'),(1716,25,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33'),(1717,47,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33'),(1718,48,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33'),(1719,49,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33'),(1720,26,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33'),(1721,50,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33'),(1722,51,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33'),(1723,52,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33'),(1724,27,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33'),(1725,53,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33'),(1726,54,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33'),(1727,55,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33'),(1728,3,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33'),(1729,39,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33'),(1730,68,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33'),(1731,69,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33'),(1732,70,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33'),(1733,40,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33'),(1734,4,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33'),(1735,42,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33'),(1736,71,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33'),(1737,72,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33'),(1738,5,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33'),(1739,28,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33'),(1740,56,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33'),(1741,57,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33'),(1742,58,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33'),(1743,29,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33'),(1744,59,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33'),(1745,60,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33'),(1746,61,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33'),(1747,30,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33'),(1748,31,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33'),(1749,6,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33'),(1750,32,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33'),(1751,62,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33'),(1752,63,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33'),(1753,64,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33'),(1754,33,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33'),(1755,35,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33'),(1756,37,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33'),(1757,65,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33'),(1758,66,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33'),(1759,67,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33'),(1760,7,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33'),(1761,34,1,NULL,'2019-06-21 22:46:33','2019-06-21 22:46:33');
/*!40000 ALTER TABLE `tbl_phanquyen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_quangcao`
--

DROP TABLE IF EXISTS `tbl_quangcao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_quangcao` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `images` longtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contentsads` longtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_quangcao`
--

LOCK TABLES `tbl_quangcao` WRITE;
/*!40000 ALTER TABLE `tbl_quangcao` DISABLE KEYS */;
INSERT INTO `tbl_quangcao` (`id`, `name`, `images`, `url`, `contentsads`, `status`, `created_at`, `updated_at`) VALUES (1,'Qc left sidebar','https://shopxinh.com.vn/public/upload/images/qc.jpg','#',NULL,1,'2019-08-20 09:46:07','2019-08-20 09:46:07'),(2,'quang cao 2','https://shopxinh.com.vn/public/upload/images/qc1.jpg','#',NULL,1,'2019-08-20 09:48:49','2019-08-20 09:48:49'),(3,'quang cao 3','https://shopxinh.com.vn/public/upload/images/qc2.jpg','#',NULL,1,'2019-08-20 09:49:05','2019-08-20 09:49:05');
/*!40000 ALTER TABLE `tbl_quangcao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_quantri`
--

DROP TABLE IF EXISTS `tbl_quantri`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_quantri` (
  `ma` int(11) NOT NULL AUTO_INCREMENT,
  `ten` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tendangnhap` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `matkhau` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `manhom` int(11) DEFAULT NULL,
  `trangthai` int(11) DEFAULT NULL COMMENT '0: an, 1: hien, -1:xoa',
  `ngaytao` datetime DEFAULT current_timestamp(),
  `ngaycapnhat` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`ma`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_quantri`
--

LOCK TABLES `tbl_quantri` WRITE;
/*!40000 ALTER TABLE `tbl_quantri` DISABLE KEYS */;
INSERT INTO `tbl_quantri` (`ma`, `ten`, `tendangnhap`, `matkhau`, `manhom`, `trangthai`, `ngaytao`, `ngaycapnhat`) VALUES (1,'Duong van nha','admin','e10adc3949ba59abbe56e057f20f883e',1,1,'2019-05-22 18:05:30','2019-05-22 18:05:30');
/*!40000 ALTER TABLE `tbl_quantri` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_role_user`
--

DROP TABLE IF EXISTS `tbl_role_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_role_user` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_role_user`
--

LOCK TABLES `tbl_role_user` WRITE;
/*!40000 ALTER TABLE `tbl_role_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_role_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_roles`
--

DROP TABLE IF EXISTS `tbl_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_roles`
--

LOCK TABLES `tbl_roles` WRITE;
/*!40000 ALTER TABLE `tbl_roles` DISABLE KEYS */;
INSERT INTO `tbl_roles` (`id`, `name`, `description`, `status`, `created_at`, `updated_at`) VALUES (1,'Administrator','Quyền quản trị toàn bộ website',1,NULL,NULL),(2,'Quản lý sản phẩm','Quyền quản lý sản phẩm',1,NULL,NULL),(3,'Quản lý bài viết','Quyền quản lý bài viết',1,NULL,NULL);
/*!40000 ALTER TABLE `tbl_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_roles_permissions`
--

DROP TABLE IF EXISTS `tbl_roles_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_roles_permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` bigint(20) DEFAULT NULL,
  `permissions_id` bigint(20) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_roles_permissions`
--

LOCK TABLES `tbl_roles_permissions` WRITE;
/*!40000 ALTER TABLE `tbl_roles_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_roles_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_sanpham`
--

DROP TABLE IF EXISTS `tbl_sanpham`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_sanpham` (
  `ma` int(11) NOT NULL AUTO_INCREMENT,
  `ma_sp` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_sp` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gia_sp` bigint(20) DEFAULT NULL,
  `mota_sp` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `hinh_sp` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `video` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `soluong_sp` int(11) DEFAULT NULL,
  `ds_hinh` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `mota_chitiet` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tieude_sp` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tukhoa_sp` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `desc_sp` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hinh_share` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `link_alias` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ma_ncc` int(11) DEFAULT NULL,
  `ma_loai` int(11) DEFAULT NULL,
  `ma_thuonghieu` int(11) DEFAULT NULL,
  `trangthai_sp` int(11) DEFAULT NULL COMMENT '0: an;1:hien;-11:xoa',
  `ngaytao_sp` datetime DEFAULT current_timestamp(),
  `ngay_update_sp` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`ma`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_sanpham`
--

LOCK TABLES `tbl_sanpham` WRITE;
/*!40000 ALTER TABLE `tbl_sanpham` DISABLE KEYS */;
INSERT INTO `tbl_sanpham` (`ma`, `ma_sp`, `ten_sp`, `gia_sp`, `mota_sp`, `hinh_sp`, `video`, `soluong_sp`, `ds_hinh`, `mota_chitiet`, `tieude_sp`, `tukhoa_sp`, `desc_sp`, `hinh_share`, `link_alias`, `ma_ncc`, `ma_loai`, `ma_thuonghieu`, `trangthai_sp`, `ngaytao_sp`, `ngay_update_sp`) VALUES (8,'SDXN01','Sandal Nữ Xỏ Ngón BIGGBEN Da Bò Thật',270000,'<p>Chất liệu da bò độ bền cao, bóng đẹp</p>\r\n\r\n<p>Đế cao su cao mang lại sự thoải mái, chống trơn trượt</p>\r\n\r\n<p>Form dáng chuẩn, ôm gọn đôi bàn chân</p>','https://shopxinh.com.vn/public/upload/images/xongon.jpg',NULL,100,NULL,'Sandal Nữ với chất liệu da bò bền đẹp kết hợp đế cao su êm nhẹ chống trơn trượt giúp bạn Nữ luôn thoải mái, tự tin khi đi chơi, dạo phố, đi làm nơi công sở hay đi dự tiệc.<br />\r\nSandal Nữ được xử lý đặc biệt để tạo độ bóng mờ Nữ tính thích hợp cho mọi lứa tuổi.<br />\r\nĐế cao Su cao cấp chẳng những êm ái mang lại sự thoải mái tối đa cho người dùng, mà mặt đế còn có độ bám tốt để bạn có thể sải bước thật vững vàng và tự tin.<br />\r\nBạn có thể kết hợp với các loại trang phục hằng ngày tùy theo sở thích và phong cách của mình','Sandal Nữ Xỏ Ngón BIGGBEN Da Bò Thật','Sandal Nữ Xỏ Ngón BIGGBEN Da Bò Thật','Sandal Nữ Xỏ Ngón BIGGBEN Da Bò Thật','http://localhost/doanlaravelbanhang/public/upload/images/xongon.jpg','sandal-nu-xo-ngon-biggben-da-bo-that',8,1,7,1,'2019-08-19 22:42:37','2019-08-19 22:42:37'),(9,'SDN08','Sandal Nữ BIGGBEN Da Bò Thật',300000,'<p>Chất liệu da bò độ bền cao, bóng đẹp</p>\r\n\r\n<p>Đế cao su cao mang lại sự thoải mái, chống trơn trượt</p>\r\n\r\n<p>Form dáng chuẩn, ôm gọn đôi bàn chân</p>','https://shopxinh.com.vn/public/upload/images/SDN08.jpg',NULL,100,NULL,'Sandal Nữ với chất liệu da bò bền đẹp kết hợp đế cao su êm nhẹ chống trơn trượt giúp bạn Nữ luôn thoải mái, tự tin khi đi chơi, dạo phố, đi làm nơi công sở hay đi dự tiệc.<br />\r\nSandal Nữ được xử lý đặc biệt để tạo độ bóng mờ, Phong cách trẻ trung và Nữ tính.<br />\r\nĐế cao Su cao cấp chẳng những êm ái mang lại sự thoải mái tối đa cho người dùng, mà mặt đế còn có độ bám tốt để bạn có thể sải bước thật vững vàng và tự tin.<br />\r\nBạn có thể kết hợp với các loại trang phục hằng ngày tùy theo sở thích và phong cách của mình<br />\r\nHướng dẫn chọn size:\r\n<div style=\"text-align: center;\"><img alt=\"\" height=\"152\" src=\"https://vcdn.tikicdn.com/ts/tmp/c0/e7/a9/e3b6ab1eb9c6bda92ddc02fdb18f4358.JPG\" style=\"vertical-align:middle;border:0px;height:auto;\" width=\"620\" /></div>','Sandal Nữ BIGGBEN Da Bò Thật','Sandal Nữ BIGGBEN Da Bò Thật','Sandal Nữ BIGGBEN Da Bò Thật','http://localhost/doanlaravelbanhang/public/upload/images/SDN08.jpg','sandal-nu-biggben-da-bo-that',8,1,7,1,'2019-08-19 22:45:11','2019-08-19 22:45:11'),(10,'DNQN20','Dép Nữ BIGGBEN Da Bò Thật',270000,'<p>Chất liệu da bò độ bền cao, bóng đẹp</p>\r\n\r\n<p>Đế cao su cao mang lại sự thoải mái, chống trơn trượt</p>\r\n\r\n<p>Form dáng chuẩn, ôm gọn đôi bàn chân</p>','https://shopxinh.com.vn/public/upload/images/DNQN20.jpg',NULL,100,NULL,'Dép Nữ với chất liệu da bò bền đẹp kết hợp đế cao su êm nhẹ chống trơn trượt giúp bạn Nữ luôn thoải mái, tự tin khi đi chơi, dạo phố, đi làm nơi công sở hay đi dự tiệc.<br />\r\nDép Nữ được xử lý đặc biệt để tạo độ bóng mờ Nữ tính thích hợp cho mọi lứa tuổi.<br />\r\nĐế cao Su cao cấp chẳng những êm ái mang lại sự thoải mái tối đa cho người dùng, mà mặt đế còn có độ bám tốt để bạn có thể sải bước thật vững vàng và tự tin.<br />\r\nBạn có thể kết hợp với các loại trang phục hằng ngày tùy theo sở thích và phong cách của mình<br />\r\nHướng dẫn chọn size:\r\n<div style=\"text-align: center;\"><img alt=\"\" height=\"155\" src=\"https://vcdn.tikicdn.com/ts/tmp/c0/e7/a9/e3b6ab1eb9c6bda92ddc02fdb18f4358.JPG\" style=\"vertical-align:middle;border:0px;height:auto;\" width=\"620\" /></div>\r\n\r\n<div style=\"text-align: center;\"></div>','Dép Nữ BIGGBEN Da Bò Thật','Dép Nữ BIGGBEN Da Bò Thật','Dép Nữ BIGGBEN Da Bò Thật','http://localhost/doanlaravelbanhang/public/upload/images/DNQN20.jpg','dep-nu-biggben-da-bo-that',8,1,7,1,'2019-08-19 22:48:38','2019-08-19 22:48:38'),(11,'KTNT01','Set 4 kẹp tóc ngọc trai Hàn Quốc',100000,'<p>Kẹp tóc ngọc trai phong cách Hàn Quốc</p>\r\n\r\n<p>Chất liệu: Hợp kim, ngọc trai nhân tạo</p>\r\n\r\n<p>Kích thước: Khoảng 08 cm</p>\r\n\r\n<p>Thiết kế độc đáo, lạ mắt, tinh tế</p>\r\n\r\n<p>Kiểu dáng lạ mắt, xu hướng thời trang hot trend</p>\r\n\r\n<p>Mang đến cho bạn vẻ đẹp thanh lịch, sang trọng</p>\r\n\r\n<p>Dễ dàng phối với nhiều loại trang phục, phụ kiện đi kèm</p>\r\n\r\n<p>Quà tặng ý nghĩa cho người thân yêu</p>','https://shopxinh.com.vn/public/upload/images/keptoc.jpg',NULL,100,NULL,'<p>Phụ kiện ngọc trai tưởng già, nhưng nhìn xu hướng năm nay bạn sẽ muốn sắm ngay đủ bộ từ khuyên tai đến nhẫn. Với thiết kế trẻ trung, hiện đại, phụ kiện ngọc trai đang là món đồ khiến bao cô nàng mê mẩn và kết hợp cực ngọt với những bộ trang phục mang nhiều phong cách khác nhau.</p>\r\n\r\n<p></p>\r\n\r\n<p style=\"text-align: center;\"><img alt=\"\" height=\"750\" src=\"https://salt.tikicdn.com/ts/tmp/20/60/0d/c22bfd6b614fcc72bcfd0094b32caeb5.jpg\" width=\"750\" /></p>\r\n\r\n<p></p>\r\n\r\n<p>Lưu ý: Để sản phẩm luôn được sáng bóng, khách hàng có thể bảo quản sản phẩm ở nơi khô ráo, tránh tiếp xúc sản phẩm với các hóa chất tẩy rửa cao. Dùng giấy hoặc vải mềm hay hộp đựng trang sức chuyên dụng để bảo quản khi bạn không có nhu cầu đeo nữa (nên làm sạch và làm khô trước khi cất giữ).</p>','Set 4 kẹp tóc ngọc trai Hàn Quốc','Set 4 kẹp tóc ngọc trai Hàn Quốc','Set 4 kẹp tóc ngọc trai Hàn Quốc',NULL,'set-4-kep-toc-ngoc-trai-han-quoc',8,6,7,1,'2019-08-19 22:51:38','2019-08-19 22:51:38'),(12,'MVR01','Mũ rộng vành chống nắng thời trang',50000,'<p>Chất liệu mềm mại, thoáng mát thấm hút mồ hôi</p>\r\n\r\n<p>Thiết kế rộng vành che phủ tốt, chống nắng hiệu quả</p>\r\n\r\n<p>Kiểu dáng trẻ trung, thời trang thích hợp mang theo khi đi du lịch</p>\r\n\r\n<p>Màu sặc trẻ trung phù hợp mọi lứa tuổi</p>','https://shopxinh.com.vn/public/upload/images/mu.jpg',NULL,100,NULL,'<p>Chất liệu mềm mại, thoáng mát thấm hút mồ hôi</p>\r\n\r\n<p>Thiết kế rộng vành che phủ tốt, chống nắng hiệu quả</p>\r\n\r\n<p>Kiểu dáng trẻ trung, thời trang thích hợp mang theo khi đi du lịch</p>\r\n\r\n<p>Màu sặc trẻ trung phù hoepj mọi lứa tuổi</p>','Mũ rộng vành chống nắng thời trang','Mũ rộng vành chống nắng thời trang','Mũ rộng vành chống nắng thời trang','http://localhost/doanlaravelbanhang/public/upload/images/mu.jpg','mu-rong-vanh-chong-nang-thoi-trang',8,6,6,1,'2019-08-19 22:54:52','2019-08-19 22:54:52'),(13,'BRYCETON','Giày Tây Nam GEOX',2700000,'<p>Chất liệu cao cấp tạo sự thoải mái khi sử dụng</p>\r\n\r\n<p>Thiết kế theo công nghệ biết thở với các lỗ thoáng khí</p>\r\n\r\n<p>Đế nhẹ, đàn hồi và ma sát tốt, chống trơn trượt</p>\r\n\r\n<p>Dễ phối cùng nhiều kiểu trang phục khác nhau</p>','https://shopxinh.com.vn/public/upload/images/giaytay.jpg',NULL,100,NULL,'<p>Chất liệu cao cấp tạo sự thoải mái khi sử dụng</p>\r\n\r\n<p>Thiết kế theo công nghệ biết thở với các lỗ thoáng khí</p>\r\n\r\n<p>Đế nhẹ, đàn hồi và ma sát tốt, chống trơn trượt</p>\r\n\r\n<p>Dễ phối cùng nhiều kiểu trang phục khác nhau</p>','Giày Tây Nam GEOX','Giày Tây Nam GEOX','Giày Tây Nam GEOX',NULL,'giay-tay-nam-geox',9,2,9,1,'2019-08-19 22:57:29','2019-08-19 22:57:29'),(14,'DEIVEN','Giày Sneakers Nam GEOX',2695000,'<p>Công nghệ đế thở: Thông thoáng và giảm nhiệt</p>\r\n\r\n<p>Lót trong: vải mesh</p>\r\n\r\n<p>Lót giày có thể tháo rời</p>\r\n\r\n<p>Đế EVA siêu nhẹ</p>','https://shopxinh.com.vn/public/upload/images/sneker.jpg',NULL,100,NULL,'<ul>\r\n	<li><strong>Giày Sneakers Nam GEOX U DEIVEN A</strong> được thiết kế trẻ trung, năng động và sành điệu, khẳng định phong cách thời trang riêng của phái mạnh.</li>\r\n	<li>Tông màu nam tính, đẳng cấp cùng chất liệu cao cấp mềm mại, không mang đến cảm giác đau chân khi phải di chuyển nhiều, sản phẩm tạo nên sự tin tưởng tuyệt đối trong sự lựa chọn của giới trẻ thời nay.</li>\r\n	<li>Đế có xẻ rãnh chống trơn trượt, tạo sự êm ái và nhẹ nhàng khi di chuyển.</li>\r\n	<li>Thiết kế này luôn được ưa chuộng vì dễ dàng kết hợp cùng nhiều phong cách thời trang khác nhau. Bạn có thể kết hợp giày cùng áo thun, áo sơ mi và quần jean, đều phù hợp khi đi làm, đi chơi, đi tiệc,</li>\r\n</ul>\r\n\r\n<p><strong>Hướng dẫn chọn size:</strong></p>\r\n\r\n<p style=\"text-align: center;\"><img height=\"464\" src=\"https://salt.tikicdn.com/ts/tmp/db/d0/cf/8beb67304a3c3ca80190381b4802c165.JPG\" width=\"355\" /></p>','Giày Sneakers Nam GEOX','Giày Sneakers Nam GEOX','Giày Sneakers Nam GEOX',NULL,'giay-sneakers-nam-geox',9,2,9,1,'2019-08-19 22:59:17','2019-08-19 22:59:17'),(15,'BayleA','Giày Tây Nam Geox U Bayle A',5850000,'<p>Material: 100% Leather Bovine</p>\r\n\r\n<p>Thiết kế: Cùng với xu hướng giày loafer, phát triển thêm về chất liệu và kiểu dáng, tinh tế</p>\r\n\r\n<p>Da toàn bộ thân giày, dễ sử dụng</p>','https://shopxinh.com.vn/public/upload/images/blye.jpg',NULL,100,NULL,'<ul>\r\n	<li><strong>Giày Tây Nam Geox U Bayle A</strong> được thiết kế với gam màu hiện đại cho bạn nam thể hiện phong cách sang trọng, lịch lãm.</li>\r\n	<li>Đôi bàn chân luôn thông thoáng, mát mẻ, và cực kỳ dễ chịu là những điều khách hàng cảm nhận khi mang.</li>\r\n	<li>Sự khác biệt của GEOX so với các thương hiệu giày khác chính là đế giày “biết thở” với lớp màng lọc giúp cho hơi nóng của mồ hôi thoát ra ngoài nhưng hoàn toàn ngăn không cho nước thấm ngược vào bên trong.</li>\r\n	<li>Giày biết thở GEOX là sự kết hợp giữa các thiết kế châu Âu và công nghệ độc quyền mang đến cho người sử dụng sự thoải mái, êm ái mà vẫn vô cùng lịch lãm, thời trang.</li>\r\n</ul>\r\n\r\n<p style=\"text-align: center;\"><img alt=\"\" height=\"562\" src=\"https://salt.tikicdn.com/ts/product/85/af/ca/46cc8b898cb10a5eb8c991a8c4548f67.jpg\" width=\"750\" /></p>\r\n\r\n<p><strong>Hướng dẫn chọn size</strong></p>\r\n\r\n<p style=\"text-align: center;\"><img height=\"521\" src=\"https://salt.tikicdn.com/ts/product/f0/ab/cb/84888d8e71dce79fded658d79077fd35.jpg\" width=\"750\" /></p>','Giày Tây Nam Geox U Bayle A','Giày Tây Nam Geox U Bayle A','Giày Tây Nam Geox U Bayle A',NULL,'giay-tay-nam-geox-u-bayle-a',9,2,9,1,'2019-08-19 23:01:11','2019-08-19 23:01:11'),(16,'AT040','Ví Nam At Leather AT040-Đ (11.5 x 10 cm) - Đen',230000,'<p>Kiểu dáng ví đứng đơn giản, sang trọng</p>\r\n\r\n<p>Chất liệu 100% da bền đẹp</p>\r\n\r\n<p>Thiết kế viền chỉ màu đẹp mắt</p>\r\n\r\n<p>Ví có nhiều ngăn đựng tiện lợi</p>','https://shopxinh.com.vn/public/upload/images/viat.jpg',NULL,100,NULL,'<ul>\r\n	<li><strong>Ví Nam At Leather AT040-Đ (11.5 x 10 cm) - Đen</strong> không chỉ là một trong những vật dụng thiết yếu mà còn là một món đồ góp phần giúp phái mạnh khẳng định đẳng cấp và sự sành điệu của mình.</li>\r\n	<li>Ví được gia công tinh xảo từ 100% chất liệu da cao cấp mang lại form dáng cực chuẩn và độ bền cao.</li>\r\n	<li>Ví có thiết kế nhiều ngăn đựng tiện lợi giúp bạn dễ dàng mang theo các loại giấy tờ, vật dụng cá nhân như tiền bạc, thẻ ATM, CMND, cà vẹt xe, </li>\r\n	<li>Nhờ vào kiểu dáng đơn giản nhưng không kém phần sang trọng ví có thể diện cùng với bộ trang phục “tông xuyệt tông”, chắc chắn bạn sẽ trở thành tâm điểm trong một bữa tiệc hay ánh mắt ai đó sẽ không rời được khỏi bạn.</li>\r\n</ul>','Ví Nam At Leather AT040-Đ (11.5 x 10 cm) - Đen','Ví Nam At Leather AT040-Đ (11.5 x 10 cm) - Đen','Ví Nam At Leather AT040-Đ (11.5 x 10 cm) - Đen',NULL,'vi-nam-at-leather-at040-d-(11-5-x-10-cm)-den',9,6,11,1,'2019-08-19 23:05:44','2019-08-19 23:05:44'),(17,'P106','Thắt Lưng Nam Cao Cấp AT Leather P106 - Đen',180000,'<p>Chất liệu da thật</p>\r\n\r\n<p>Đầu khóa hợp kim không gỉ sáng bóng thời thượng</p>\r\n\r\n<p>Đường chỉ may tỉ mỉ, chắc chắn</p>\r\n\r\n<p>Kiểu dáng đẳng cấp sang trọng</p>\r\n\r\n<p>Tông màu lịch lãm, dễ kết hợp trang phục</p>','https://shopxinh.com.vn/public/upload/images/daynit.jpg',NULL,100,NULL,'<ul>\r\n	<li><strong>Thắt Lưng Nam Cao Cấp AT Leather P106 - Đen </strong>được làm từ chất liệu da bò đã qua quy trình xử lý kỳ công giúp cho bề mặt sản phẩm luôn có độ bóng đẹp hoàn hảo.</li>\r\n	<li>Bề mặt da không bị rạn nứt hay gãy đứt trong suốt thời gian sử dụng.</li>\r\n	<li>Đầu khóa hợp kim không gỉ chắc chắn và siêu bền, có thể dễ dàng tùy chỉnh kích cỡ cho phù hợp với vóc dáng cơ thể.</li>\r\n	<li>Sản phẩm như món phụ kiện thời trang cao cấp dành cho quý ông trẻ trung, sành điệu. Được gia công tỉ mỉ và tinh xảo giúp gia tăng tuổi thọ dài lâu khi sử dụng.</li>\r\n	<li>Dễ dàng kết hợp cùng quần jeans, kaki, áo sơ mi, áo thun, nhằm mang lại vẻ ngoài lịch thiệp và sang trọng cho đấng mày râu.</li>\r\n</ul>','Thắt Lưng Nam Cao Cấp AT Leather P106 - Đen','Thắt Lưng Nam Cao Cấp AT Leather P106 - Đen','Thắt Lưng Nam Cao Cấp AT Leather P106 - Đen',NULL,'that-lung-nam-cao-cap-at-leather-p106-den',9,6,10,1,'2019-08-19 23:07:29','2019-08-19 23:07:29'),(18,'NT63','Thắt lưng nam, dây nịt nam da thật NT63',100000,'<p>Chất liệu da thật 100% , chống đứt gãy</p>\r\n\r\n<p>Đầu khóa hợp kim không gỉ sáng bóng thời thượng</p>\r\n\r\n<p>Đường chỉ may tỉ mỉ, chắc chắn</p>\r\n\r\n<p>Kiểu dáng đẳng cấp sang trọng</p>\r\n\r\n<p>Tông màu lịch lãm, dễ kết hợp trang phục</p>','https://shopxinh.com.vn/public/upload/images/nt63.jpg',NULL,100,NULL,'<ul>\r\n	<li>Thắt Lưng Nam NT63 được làm từ chất liệu da thật 100% cao cấp đã qua quy trình xử lý kỳ công giúp cho bề mặt sản phẩm luôn có độ bóng đẹp hoàn hảo.</li>\r\n	<li>Bề mặt da không bị rạn nứt hay gãy đứt trong suốt thời gian sử dụng.</li>\r\n	<li>Đầu khóa hợp kim không gỉ chắc chắn và siêu bền, có thể dễ dàng tùy chỉnh kích cỡ cho phù hợp với vóc dáng cơ thể.</li>\r\n	<li>Sản phẩm như món phụ kiện thời trang cao cấp dành cho quý ông trẻ trung, sành điệu. Được gia công tỉ mỉ và tinh xảo giúp gia tăng tuổi thọ dài lâu khi sử dụng.</li>\r\n	<li>Dễ dàng kết hợp cùng quần jeans, kaki, áo sơ mi, áo thun,... nhằm mang lại vẻ ngoài lịch thiệp và sang trọng cho đấng mày râu.</li>\r\n</ul>','Thắt lưng nam, dây nịt nam da thật NT63','Thắt lưng nam, dây nịt nam da thật NT63','Thắt lưng nam, dây nịt nam da thật NT63',NULL,'that-lung-nam-day-nit-nam-da-that-nt63',9,6,10,1,'2019-08-19 23:09:07','2019-08-19 23:09:07'),(19,'AV125','Thắt Lưng Nam AVAKA',150000,'<p>Sản phẩm được đảm bảo chất lượng</p>\r\n\r\n<p>Thiết kế thời trang</p>\r\n\r\n<p>Chất liệu cao cấp</p>\r\n\r\n<p>Kiểu dáng phong cách</p>\r\n\r\n<p>Độ bền cao</p>\r\n\r\n<p>Dễ phối đồ</p>\r\n\r\n<p>Thương Hiệu Việt: AVAKA</p>','https://shopxinh.com.vn/public/upload/images/av.jpg',NULL,100,NULL,'<p><strong>GIỚI THIỆU SẢN PHẨM THẮT LƯNG AVAKA AV125</strong></p>\r\n\r\n<p style=\"text-align: center;\"><img src=\"https://salt.tikicdn.com/ts/product/67/c2/96/75857fefebe3075493c33b26cc368a71.jpg\" /><br />\r\n </p>\r\n\r\n<p><strong>Đặc điểm nổi bật của sản phẩm:</strong></p>\r\n\r\n<p><strong>- Chất liệu cao cấp & bền:</strong> Thắt lưng được làm từ chất liệu da cao cấp, luôn đem lại cảm giác mềm mại, êm khi sử dụng và bền chắc.</p>\r\n\r\n<p><strong>- Thiết kế hiện đại và thời trang:</strong> Thắt lưng được thiết kế độc đáo, quai đeo bền chắc cùng kiểu dáng hình chữ nhật ngang kết hợp tinh tế giữa nét cổ điển và hiện đại, tạo nên sự hài hòa tuyệt đối.</p>\r\n\r\n<p><strong>- Đường may tỉ mỉ chắc chắn:</strong> Đường may của sản phẩm vô cùng tỉ mỉ và tinh tế, đảm bảo độ bền chắc trong suốt thời gian bạn sử dụng. Chiếc thắt lưng sẽ mang đến cho bạn vẻ đẹp thật trẻ trung và năng động.</p>\r\n\r\n<p><strong>- Dễ dàng phối đồ:</strong>  Thắt lưng với tông màu trung tính, không chỉ giúp bạn thể hiện phong cách thời trang cá tính mà còn rất dễ dàng khi phối đồ. Thắt lưng có thể kết hợp cùng nhiều trang phục như: quần jean, quần âu và các phụ kiện khác để trở nên thật nổi bật.</p>\r\n\r\n<p><strong>- Bảo quản đơn giản:</strong> Sản phẩm dễ dàng bảo quản và vệ sinh.     </p>\r\n\r\n<p></p>\r\n\r\n<p style=\"text-align: center;\"><img src=\"https://salt.tikicdn.com/ts/product/8b/7f/e7/5cb6e73852d86dfd99c9125bfa14d9b9.jpg\" /></p>\r\n\r\n<p></p>\r\n\r\n<p style=\"text-align: center;\"><img src=\"https://salt.tikicdn.com/ts/product/11/e9/3f/8e8b4b3124375a2f2a669a7fd5ef9eab.jpg\" /></p>\r\n\r\n<p></p>\r\n\r\n<p style=\"text-align: center;\"><img src=\"https://salt.tikicdn.com/ts/product/be/4e/e6/f1b9493e939d62f6ae413b079ebe21b5.jpg\" /></p>\r\n\r\n<p></p>\r\n\r\n<p style=\"text-align: center;\"><img src=\"https://salt.tikicdn.com/ts/product/90/82/a6/048eb31ca0e652c95455d2762ecf8076.jpg\" /></p>\r\n\r\n<p></p>\r\n\r\n<p style=\"text-align: center;\"><img src=\"https://salt.tikicdn.com/ts/product/03/64/f3/68d688783d4e7ddf865503d24a72e619.jpg\" /></p>\r\n\r\n<p></p>\r\n\r\n<p style=\"text-align: center;\"><img src=\"https://salt.tikicdn.com/ts/product/78/be/30/397356fa5824d5272077d2ce252f74c5.jpg\" /></p>\r\n\r\n<p></p>\r\n\r\n<p style=\"text-align: center;\"><img src=\"https://salt.tikicdn.com/ts/product/67/c2/96/75857fefebe3075493c33b26cc368a71.jpg\" /></p>','Thắt Lưng Nam AVAKA','Thắt Lưng Nam AVAKA','Thắt Lưng Nam AVAKA',NULL,'that-lung-nam-avaka',9,6,8,1,'2019-08-19 23:11:33','2019-08-19 23:11:33'),(20,'P111','Thắt Lưng Nam AT Leather',150000,'<p>Chất liệu da bò 100%</p>\r\n\r\n<p>Đầu khóa hợp kim không gỉ sáng bóng thời thượng</p>\r\n\r\n<p>Đường chỉ may tỉ mỉ, chắc chắn</p>\r\n\r\n<p>Kiểu dáng đẳng cấp sang trọng</p>\r\n\r\n<p>Tông màu lịch lãm, dễ kết hợp trang phục</p>','https://shopxinh.com.vn/public/upload/images/p11.jpg',NULL,100,NULL,'<ul>\r\n	<li><strong>Thắt Lưng Nam AT Leather P111</strong> được làm từ chất liệu da bò 100% đã qua quy trình xử lý kỳ công giúp cho bề mặt sản phẩm luôn có độ bóng đẹp hoàn hảo.</li>\r\n	<li>Bề mặt da không bị rạn nứt hay gãy đứt trong suốt thời gian sử dụng.</li>\r\n	<li>Đầu khóa hợp kim không gỉ chắc chắn và siêu bền, có thể dễ dàng tùy chỉnh kích cỡ cho phù hợp với vóc dáng cơ thể.</li>\r\n	<li>Sản phẩm như món phụ kiện thời trang cao cấp dành cho quý ông trẻ trung, sành điệu. Được gia công tỉ mỉ và tinh xảo giúp gia tăng tuổi thọ dài lâu khi sử dụng.</li>\r\n	<li>Dễ dàng kết hợp cùng quần jeans, kaki, áo sơ mi, áo thun,... nhằm mang lại vẻ ngoài lịch thiệp và sang trọng cho đấng mày râu.</li>\r\n</ul>','Thắt Lưng Nam AT Leather','Thắt Lưng Nam AT Leather','Thắt Lưng Nam AT Leather',NULL,'that-lung-nam-at-leather',9,6,11,1,'2019-08-19 23:13:07','2019-08-19 23:13:07');
/*!40000 ALTER TABLE `tbl_sanpham` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_setting`
--

DROP TABLE IF EXISTS `tbl_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_setting` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `logo` longtext COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `keyword` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `descriptions` longtext COLLATE utf8_unicode_ci NOT NULL,
  `hotline` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `diachi` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `timezone` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_setting`
--

LOCK TABLES `tbl_setting` WRITE;
/*!40000 ALTER TABLE `tbl_setting` DISABLE KEYS */;
INSERT INTO `tbl_setting` (`id`, `logo`, `title`, `keyword`, `descriptions`, `hotline`, `email`, `diachi`, `timezone`, `created_at`, `updated_at`) VALUES (1,'http://localhost/doanlaravelbanhang/public/upload/images/logo.png','ShopXinh.com.vn - Shop thời trang nam, nữ, mỹ phẩm, handmade','Shop thời trang nam, nữ, mỹ phẩm, handmade, đồ da handmade','Shop chuyên thời trang nam, nữ, mỹ phẩm, handmade, đồ da handmade','0966487384','dvnha0105@gmail.com','Trung Lập Hạ, Củ Chi, Tp.HCM','Asia/Ho_Chi_Minh',NULL,'2019-07-28 02:55:58');
/*!40000 ALTER TABLE `tbl_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_slide`
--

DROP TABLE IF EXISTS `tbl_slide`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_slide` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `link` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `images` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_slide`
--

LOCK TABLES `tbl_slide` WRITE;
/*!40000 ALTER TABLE `tbl_slide` DISABLE KEYS */;
INSERT INTO `tbl_slide` (`id`, `title`, `description`, `link`, `images`, `status`, `created_at`, `updated_at`) VALUES (5,NULL,NULL,'#','https://shopxinh.com.vn/public/upload/images/slide.jpg',1,'2019-08-20 22:09:57','2019-08-20 22:09:57'),(6,NULL,NULL,'#','https://shopxinh.com.vn/public/upload/images/slide2(1).jpg',1,'2019-08-20 22:10:22','2019-08-20 22:10:22'),(7,NULL,NULL,'#','https://shopxinh.com.vn/public/upload/images/slide3(1).jpg',1,'2019-08-20 22:10:30','2019-08-20 22:10:30'),(8,NULL,NULL,'#','https://shopxinh.com.vn/public/upload/images/slide4(1).jpg',1,'2019-08-20 22:10:38','2019-08-20 22:10:38'),(9,NULL,NULL,'#','https://shopxinh.com.vn/public/upload/images/slide5.jpg',1,'2019-08-20 22:10:48','2019-08-20 22:10:48');
/*!40000 ALTER TABLE `tbl_slide` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_thuonghieu`
--

DROP TABLE IF EXISTS `tbl_thuonghieu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_thuonghieu` (
  `ma_thuonghieu` int(11) NOT NULL AUTO_INCREMENT,
  `ten_thuonghieu` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `logo_thuonghieu` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mota_thuonghieu` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tieude_thuonghieu` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tukhoa_thuonghieu` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mota_seo_thuonghieu` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hinh_share_thuonghieu` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `link_alias_thuonghieu` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `trangthai_thuonghieu` int(11) DEFAULT NULL COMMENT '0:an; 1:hien;-1:xoa',
  `ngaytao_thuonghieu` datetime DEFAULT current_timestamp(),
  `ngay_update_thuonghieu` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`ma_thuonghieu`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_thuonghieu`
--

LOCK TABLES `tbl_thuonghieu` WRITE;
/*!40000 ALTER TABLE `tbl_thuonghieu` DISABLE KEYS */;
INSERT INTO `tbl_thuonghieu` (`ma_thuonghieu`, `ten_thuonghieu`, `logo_thuonghieu`, `mota_thuonghieu`, `tieude_thuonghieu`, `tukhoa_thuonghieu`, `mota_seo_thuonghieu`, `hinh_share_thuonghieu`, `link_alias_thuonghieu`, `trangthai_thuonghieu`, `ngaytao_thuonghieu`, `ngay_update_thuonghieu`) VALUES (5,'GIORDANO','http://localhost/doanlaravelbanhang/public/upload/images/dt3.png',NULL,NULL,NULL,NULL,NULL,'giordano',1,'2019-08-19 21:45:30','2019-08-19 21:45:30'),(6,'VinaBoss',NULL,NULL,NULL,NULL,NULL,NULL,'vinaboss',1,'2019-08-19 22:34:10','2019-08-19 22:34:10'),(7,'BIGGBEN',NULL,NULL,NULL,NULL,NULL,NULL,'biggben',1,'2019-08-19 22:34:37','2019-08-19 22:34:37'),(8,'ZAVANS',NULL,NULL,NULL,NULL,NULL,NULL,'zavans',1,'2019-08-19 22:35:07','2019-08-19 22:35:07'),(9,'GEOX',NULL,NULL,NULL,NULL,NULL,NULL,'geox',1,'2019-08-19 22:36:24','2019-08-19 22:36:24'),(10,'Everest',NULL,NULL,NULL,NULL,NULL,NULL,'everest',1,'2019-08-19 22:36:45','2019-08-19 22:36:45'),(11,'Playboy',NULL,NULL,NULL,NULL,NULL,NULL,'playboy',1,'2019-08-19 22:37:04','2019-08-19 22:37:04');
/*!40000 ALTER TABLE `tbl_thuonghieu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_tintuc`
--

DROP TABLE IF EXISTS `tbl_tintuc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tintuc` (
  `ma_tintuc` int(11) NOT NULL AUTO_INCREMENT,
  `ten_tintuc` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `noidung_tintuc` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tomtat_tintuc` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hinh_thumbnail` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ma_nhomtin` int(11) DEFAULT NULL,
  `tieudeseo_tintuc` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tukhoaseo_tintuc` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `motaseo_tintuc` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hinhshare_tintuc` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `link_alias_tintuc` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `trangthai` int(11) DEFAULT NULL COMMENT '0:aan; 1:hien;-1:xoa',
  `ngaytao` datetime DEFAULT current_timestamp(),
  `ngay_update` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`ma_tintuc`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_tintuc`
--

LOCK TABLES `tbl_tintuc` WRITE;
/*!40000 ALTER TABLE `tbl_tintuc` DISABLE KEYS */;
INSERT INTO `tbl_tintuc` (`ma_tintuc`, `ten_tintuc`, `noidung_tintuc`, `tomtat_tintuc`, `hinh_thumbnail`, `ma_nhomtin`, `tieudeseo_tintuc`, `tukhoaseo_tintuc`, `motaseo_tintuc`, `hinhshare_tintuc`, `link_alias_tintuc`, `trangthai`, `ngaytao`, `ngay_update`) VALUES (2,'Ngỡ ngàng với BST váy cưới trong mơ dành tặng bạn trong sự kiện trọng đại của mình tại White Palace','Bạn sẽ là chủ nhân của chiếc váy cưới trong mơ được thiết kế và thực hiện riêng theo số đo của mình bởi Nhà thiết kế Chung Thanh Phong khi tổ chức tiệc cưới tại White Palace.<br />\r\n<br />\r\nĐược khoác lên mình chiếc váy cưới lộng lẫy từ một nhà thiết kế danh tiếng trong lễ kết hôn luôn là niềm mơ ước của biết bao cô gái.<br />\r\n<br />\r\nThấu hiểu điều đó, White Palace đã phối hợp cùng NTK Chung Thanh phong để tạo nên bộ sưu tập váy cưới như một món quà tri ân đặc biệt dành tặng cho khách hàng của mình trong ngày cưới. Mỗi thiết kế là sự kết hợp tinh tế đến từng chi tiết của chất liệu ren và voan bồng bềnh, quyến rũ, giúp tôn lên vẻ đẹp thuần khiết và thanh lịch cho cô dâu.<br />\r\n ','Thấu hiểu điều đó, White Palace đã phối hợp cùng NTK Chung Thanh phong để tạo nên bộ sưu tập váy cưới như một món quà tri ân đặc biệt dành tặng cho khách hàng của mình trong ngày cưới.','https://shopxinh.com.vn/public/upload/images/ngo-ngang-voi-bst-vay-cuoi-trong-mo-danh-nhan-ngay-trong-dai-1.jpg',1,'Ngỡ ngàng với BST váy cưới trong mơ dành tặng bạn trong sự kiện trọng đại của mình tại White Palace','Ngỡ ngàng với BST váy cưới trong mơ dành tặng bạn trong sự kiện trọng đại của mình tại White Palace','Ngỡ ngàng với BST váy cưới trong mơ dành tặng bạn trong sự kiện trọng đại của mình tại White Palace',NULL,'ngo-ngang-voi-bst-vay-cuoi-trong-mo-danh-tang-ban-trong-su-kien-trong-dai-cua-minh-tai-white-palace',1,'2019-08-19 23:51:11','2019-08-19 23:51:11'),(3,'SM bị tố đạo nhái thiết kế rồi dí cho Red Velvet mặc, netizen phát điên vì sự lôm côm của ông lớn \"Big 3\"','Red Velvet quả thực là nhóm nhạc gặp quá nhiều gian nan trong khoản ăn mặc. Thường ngày, họ luôn bị chê mặc đồ quê kiểng dìm dáng còn lần này, 5 cô gái lại vướng vào nghi án mặc đồ nhái khi quay trở lại với single \"UMPAH UMPAH\". <br />\r\n<br />\r\nNgọn ngành bắt đầu từ việc thương hiệu Paris 99 ở thành phố New York, Mỹ công khai chỉ trích SM trên Instagram. Hãng cho rằng, trang phục mà Red Velvet mặc rất giống với những thiết kế họ đã bán từ lâu. Điều đáng nói là phía SM lại chẳng hề liên lạc gì với Paris 99 mà chỉ âm thầm \"lấy\" ý tưởng rồi may đồ cho idol.\r\n<div style=\"text-align: center;\"><img alt=\"\" src=\"https://shopxinh.com.vn/public/upload/images/2.jpg\" style=\"width: 660px; height: 440px;\" /></div>\r\n<br />\r\nCó thể thấy, tuy không giống y hệt nhưng trang phục của cả 2 đều có họa tiết gingham và đặc biệc là chi tiết lượn sóng ở đường viền phần cổ, gấu váy. Vì đồ của Paris 99 đã ra mắt từ năm 2017 nên việc họ cáo buộc SM đạo nhái cũng có cơ sở.<br />\r\n<br />\r\nĐó là còn chưa kể đến concept chụp hình cungx có nhiều điểm tương đồng. Tính tới hiện tại, SM vẫn chưa có bất kỳ phát ngôn chính thức nào nhưng netizen đã lập tức dậy sóng. Tất cả mọi sự công kích, đều đang hướng về ông lớn Big 3. ','Không bị chê vì mặc đồ xấu quá mức cho phép thì Red Velvet lại rơi vào nghi án mặc đồ nhái. Trách ai bây giờ, trách SM thôi!','https://shopxinh.com.vn/public/upload/images/2.jpg',1,'SM bị tố đạo nhái thiết kế rồi dí cho Red Velvet mặc, netizen phát điên vì sự lôm côm của ông lớn \"Big 3\"','SM bị tố đạo nhái thiết kế rồi dí cho Red Velvet mặc, netizen phát điên vì sự lôm côm của ông lớn \"Big 3\"','SM bị tố đạo nhái thiết kế rồi dí cho Red Velvet mặc, netizen phát điên vì sự lôm côm của ông lớn \"Big 3\"','http://localhost/doanlaravelbanhang/public/upload/images/2.jpg','sm-bi-to-dao-nhai-thiet-ke-roi-di-cho-red-velvet-mac-netizen-phat-dien-vi-su-lom-com-cua-ong-lon-big-3',1,'2019-08-20 21:12:02','2019-08-20 21:12:02'),(4,'Từng chỉ mê mấy kiểu áo \"bao tải\" dài thượt, Linh Ka giờ lại chăm mặc crop top khoe eo thon hệt như idol Hàn Quốc','Dù có bao lần thiên biến vạn hóa với các style khác nhau thì tới cuối cùng, item mà Linh Ka diện nhiều nhất vẫn là những chiếc áo oversized vừa rộng vừa dài, đủ để cô nàng mặc theo kiểu giấu quần và cũng tiện để giấu tiệt cả 3 vòng cơ thể. Nhưng tới năm nay thì khác, tủ đồ của Linh Ka đã có nhiều xáo trộn, áo \"bao tải\" giờ đang được dần thay thế bởi 1 item tưởng lạ mà quen: crop top.<br />\r\n<br />\r\nTừ năm 2018 đổ về trước, gần như lúc nào người ta cũng thấy Linh Ka mặc áo rộng giấu dáng. Ngoài đôi chân nhỏ, người ta cũng chẳng biết thực hư vóc dáng của cô 10x này trông ra sao. Thời điểm đó, tần suất Linh Ka mặc crop top chắc chỉ đếm trên đầu ngón tay.<br />\r\n<br />\r\nNhưng tới năm nay, câu chuyện thời trang của Linh Ka đã bước sang trang khác. Cô nàng bỗng dưng tự tin khoe dáng và ra sức mặc crop top ở mọi nơi, từ phòng tập cho tới ra ngoài phố. Không những thế, cô nàng còn thử mọi chất liệu, kiểu dáng crop top khác nhau, từ cotton tới thô đũi, từ sporty khỏe khoắn tới bánh bèo điệu đà...\r\n<div style=\"text-align: center;\"><img alt=\"\" src=\"https://shopxinh.com.vn/public/upload/images/linka.jpg\" style=\"width: 960px; height: 1200px;\" /></div>\r\n<br />\r\nCó thể thấy, công thức mà Linh Ka vẫn hay áp dụng nhiều nhất vẫn là crop top + quần dài rồi đa phần là mix với sneaker hoặc mule. Thi thoảng lắm, cô nàng mới đổi gió với quần short cạp cao mà thôi.<br />\r\n<br />\r\nPhải công nhận rằng, crop top là một item hữu hiệu giúp Linh Ka khoe dáng, đặc biệt là phô diễn được vòng eo săn chắc không mỡ thừa như idol xứ kim chi. Thế mới thấy, con gái hay mặc đồ rộng không hẳn là vì họ mũm mĩm, chỉ là vì họ giấu dáng mà thôi.','Vẫn biết Linh Ka nhỏ nhắn nhưng chỉ khi cô nàng mặc crop top, dân tình mới biết thì ra cô nàng sở hữu vòng eo thon đáng ghen tị.','https://shopxinh.com.vn/public/upload/images/linka.jpg',1,'Từng chỉ mê mấy kiểu áo \"bao tải\" dài thượt, Linh Ka giờ lại chăm mặc crop top khoe eo thon hệt như idol Hàn Quốc','Từng chỉ mê mấy kiểu áo \"bao tải\" dài thượt, Linh Ka giờ lại chăm mặc crop top khoe eo thon hệt như idol Hàn Quốc','Từng chỉ mê mấy kiểu áo \"bao tải\" dài thượt, Linh Ka giờ lại chăm mặc crop top khoe eo thon hệt như idol Hàn Quốc','http://localhost/doanlaravelbanhang/public/upload/images/linka.jpg','tung-chi-me-may-kieu-ao-bao-tai-dai-thuot-linh-ka-gio-lai-cham-mac-crop-top-khoe-eo-thon-het-nhu-idol-han-quoc',1,'2019-08-20 21:18:31','2019-08-20 21:18:31'),(5,'Các cô nàng nhất định phải cẩn thận với 4 items sau, kẻo diện lên sến súa không để đâu cho hết','Diện 4 items sau đây, khó ai có thể khen bạn mặc đẹp và thời thượng cho được.<br />\r\n<br />\r\n1. Váy lòe loẹt, nhiều chi tiết\r\n<div style=\"text-align: center;\"><img alt=\"\" src=\"https://shopxinh.com.vn/public/upload/images/cac-co-nang-nhat-dinh-phai-can-than-voi-4-items-sau-keo-dien-len-sen-sua-khong-de-dau-cho-het.jpg\" style=\"width: 620px; height: 496px;\" /></div>\r\n<br />\r\nThông thường, một chiếc váy với những mảng màu lòe loẹt, rực rỡ đã là một ca siêu khó để chinh phục; nếu thêm thắt chi tiết bèo nhún nữa thì 80%, tổng thể trang phục sẽ đem đến cho bạn vẻ ngoài vô cùng rối rắm, và khó ai có thể khen bạn mặc đẹp, sành điệu cho được.<br />\r\n<br />\r\nTất nhiên, bạn vẫn có thể diện đồ màu sắc, họa tiết, nhưng hãy ưu tiên hơn những thiết kế đơn giản, hợp với sắc tố da của bạn, vậy là đủ đẹp và nổi bật.<br />\r\n<br />\r\n2. Set đồ có sự xuất hiện của quần hồng tím\r\n<div style=\"text-align: center;\"><img alt=\"\" src=\"https://shopxinh.com.vn/public/upload/images/cac-co-nang-nhat-dinh-phai-can-than-voi-4-items-sau-keo-dien-len-sen-sua-khong-de-dau-cho-het11.jpg\" style=\"width: 620px; height: 496px;\" /></div>\r\n<br />\r\nKhông phải ngẫu nhiên mà trang phục màu hồng thường bị mặc định là sến sẩm; đó là bởi sự tồn tại của những sắc độ như hồng tím.<br />\r\n<br />\r\nĐặc biệt, khi bạn diện quần hồng tím, cộng thêm trình mix&match thường thường bậc trung, set đồ dứt khoát sẽ trở nên quê kiểng, khó thẩm thấu. Vậy nên khi chọn quần, bạn hãy hướng tới những gam màu trung tính hoặc pastel nhã nhặn, tổng thể trang phục trông sẽ ưng mắt hơn hẳn.<br />\r\n<br />\r\n3. Quần hoạ tiết da báo\r\n<div style=\"text-align: center;\"><img alt=\"\" src=\"https://shopxinh.com.vn/public/upload/images/cac-co-nang-nhat-dinh-phai-can-than-voi-4-items-sau-keo-dien-len-sen-sua-khong-de-dau-cho-het2.jpg\" style=\"width: 620px; height: 496px;\" /></div>\r\n<br />\r\nMốt da báo vẫn \"hot\" điên đảo, bằng chứng là rất nhiều sao Hàn hay sao Việt tô điểm cho phong cách mùa hè của họ bằng họa tiết bắt mắt này. Nhưng nếu để ý kỹ, bạn sẽ nhận ra sự vắng bóng của quần da báo, thay vào đó, các người đẹp showbiz hay những cô nàng sành mốt chỉ diện áo, chân váy hoặc váy liền họa tiết da báo mà thôi.<br />\r\n<br />\r\nLý do là quần da báo mang một vẻ rất \"đồng bóng\", lại kén người mặc nên một khi đã liều lĩnh diện item này, bạn nên lường trước tình huống có ai đó chê set đồ của bạn khó cảm nhé!<br />\r\n<br />\r\n4. Áo blouse nhiều bèo nhún\r\n<div style=\"text-align: center;\"><img alt=\"\" src=\"https://shopxinh.com.vn/public/upload/images/cac-co-nang-nhat-dinh-phai-can-than-voi-4-items-sau-keo-dien-len-sen-sua-khong-de-dau-cho-het3.jpg\" style=\"width: 620px; height: 496px;\" /></div>\r\n<br />\r\nÁo blouse tầng tầng lớp lớp bèo nhún là điển hình cho nhận định: cái gì nhiều quá cũng không tốt; khiến người ta chơi vơi giữa ranh giới điệu đà và sến sẩm.<br />\r\n<br />\r\nNếu bạn muốn điệu mà vẫn \"chắc cốp\" tinh tế, thời thượng, hay chọn áo blouse họa tiết nhã nhặn, áo tay bồng hay tiết chế hết mức có thể chi tiết bèo nhún… Đừng quên mix với những items tối giản để đảm bảo độ hài hòa, ưng mắt cho tổng thể trang phục.','Thông thường, một chiếc váy với những mảng màu lòe loẹt, rực rỡ đã là một ca siêu khó để chinh phục; nếu thêm thắt chi tiết bèo nhún nữa thì 80%','https://shopxinh.com.vn/public/upload/images/cac-co-nang-nhat-dinh-phai-can-than-voi-4-items-sau-keo-dien-len-sen-sua-khong-de-dau-cho-het.jpg',4,'Các cô nàng nhất định phải cẩn thận với 4 items sau, kẻo diện lên sến súa không để đâu cho hết','Các cô nàng nhất định phải cẩn thận với 4 items sau, kẻo diện lên sến súa không để đâu cho hết','Các cô nàng nhất định phải cẩn thận với 4 items sau, kẻo diện lên sến súa không để đâu cho hết',NULL,'cac-co-nang-nhat-dinh-phai-can-than-voi-4-items-sau-keo-dien-len-sen-sua-khong-de-dau-cho-het',1,'2019-08-20 21:23:15','2019-08-20 21:23:15'),(6,'Nữ sinh tỉnh bơ đắp mặt nạ trong buổi tựu trường: Là hành động dễ thương tạo trend hay sắp bị cả khối ghét tới nơi rồi?','Liệu đây có phải cách gây ấn tượng trong buổi tựu trường không?<br />\r\n<br />\r\nThời đi học, cô cậu học trò nào cũng có tâm lý muốn nổi bật hơn người, từ cách chọn quần áo cho đến việc bày ra đủ thứ trend để lưu dấu kỉ niệm. Đặc biệt mùa tựu trường  cư dân mạng lại có dịp xôn xao trước những câu chuyện hài hước có 1-0-2 do chính các bạn học sinh đăng tải. <br />\r\n<br />\r\nMới đây trong group học đường, L.T.M đã chia sẻ khoảnh khắc trong đó cô bạn pose dáng cute phô mai que khi đang đắp mặt nạ. Với dòng cảm xúc ngắn gọn \"Cách để gây ấn tượng trong buổi tựu trường\", nữ sinh này đã gom cho mình hơn 26k lượt thả cảm xúc và hàng trăm bình luận từ cư dân mạng.\r\n<div style=\"text-align: center;\"><img alt=\"\" src=\"https://shopxinh.com.vn/public/upload/images/nu-sinh-tinh-bo-dap-mat-na.jpg\" style=\"width: 620px; height: 620px;\" /></div>\r\n<br />\r\nKhi bạn chưa kịp skincare thì đã tới giờ tựu trường.<br />\r\n<br />\r\nRõ ràng chẳng ai muốn buổi tựu trường trôi qua trong không khí chán ngắt cả. Thế nên còn gì tuyệt hơn khi mình có thể làm điều gì đó để chăm sóc nhan sắc một tí, lại còn có thể tạo tiếng cười diện rộng như L.T.M. Chắc chắn động lực đi học của các nữ sinh sẽ tăng lên rất nhiều vì nghĩ ra những trò vui như đã nêu trên.<br />\r\n<br />\r\n\"Câu like\" không khó, miễn bạn muốn thì đâu cũng có thể trở thành sân khấu để bạn toả sáng. Tuy nhiên, khoảnh khắc skincare của nữ sinh này lại gây tranh cãi trên MXH. Có người cho rằng nó hài hước và tag bạn bè vào để đu trend. Cũng có người cho rằng nắng nóng và bụi bẩn táp vào mặt mà còn đắp mask thì quả là không nên:<br />\r\n<br />\r\n- Này chị em, mai mang mặt nạ lên đắp chung cho dân tình trầm trồ nè.<br />\r\n<br />\r\n- Làm màu chứ ấn tượng gì. Rồi chúng nó sẽ để ý và ghét mày ngay từ giây phút này.<br />\r\n<br />\r\n- Ngồi ngoài đường đắp mặt xong tý tháo ra bụi nó lại bay vào thì cũng bằng thừa. <br />\r\n<br />\r\n- Đến lớp rửa mặt à? Rồi đắp mặt ở đấy được lợi ích gì? Thà dậy sớm sớm skincare rồi bôi kem chống nắng tự tin lên trường còn hơn. Tất nhiên là mình biết đang làm màu nên thôi không cà khịa đâu.','Thời đi học, cô cậu học trò nào cũng có tâm lý muốn nổi bật hơn người, từ cách chọn quần áo cho đến việc bày ra đủ thứ trend để lưu dấu kỉ niệm.','https://shopxinh.com.vn/public/upload/images/nu-sinh-tinh-bo-dap-mat-na.jpg',1,'Nữ sinh tỉnh bơ đắp mặt nạ trong buổi tựu trường: Là hành động dễ thương tạo trend hay sắp bị cả khối ghét tới nơi rồi?','Nữ sinh tỉnh bơ đắp mặt nạ trong buổi tựu trường: Là hành động dễ thương tạo trend hay sắp bị cả khối ghét tới nơi rồi?','Nữ sinh tỉnh bơ đắp mặt nạ trong buổi tựu trường: Là hành động dễ thương tạo trend hay sắp bị cả khối ghét tới nơi rồi?','http://localhost/doanlaravelbanhang/public/upload/images/nu-sinh-tinh-bo-dap-mat-na.jpg','nu-sinh-tinh-bo-dap-mat-na-trong-buoi-tuu-truong-la-hanh-dong-de-thuong-tao-trend-hay-sap-bi-ca-khoi-ghet-toi-noi-roi',1,'2019-08-20 21:31:20','2019-08-20 21:31:20'),(7,'Mỹ nhân hàng đầu Thái Lan diện trang phục truyền thống đẹp như nữ thần','Trang phục truyền thống là niềm tự hào của người dân Thái Lan thể hiện rõ dấu ấn văn hóa Phật giáo.\r\n<div style=\"text-align: center;\"><img alt=\"\" src=\"https://shopxinh.com.vn/public/upload/images/my-nhan-hang-dau-thai-lan-dien-trang-phuc-truyen-thong-dep-nhu-nu-than.jpg\" style=\"width: 770px; height: 1156px;\" /></div>\r\n<br />\r\nMỗi quốc gia đều có một trang phục truyền thống riêng, Việt Nam có áo dài, nhắc đến Hàn Quốc là nhớ tới hanbok, hay Nhật Bản nổi bật với kinono và Thái Lan cũng vậy. Người dân Thái coi trang phục truyền thống là niềm tự hào của họ với thiết kế giống như trang phục của nhà Phật thể hiện sự tôn thờ và hướng đạo. \r\n<div style=\"text-align: center;\"><img alt=\"\" src=\"https://shopxinh.com.vn/public/upload/images/my-nhan-hang-dau-thai-lan-dien-trang-phuc-truyen-thong-dep-nhu-nu-than1.jpg\" style=\"width: 800px; height: 1200px;\" /></div>\r\n<br />\r\nTrang phục truyền thống của Thái Lan không ôm sát cơ thể mà được may rộng, thoải mái và dễ mặc. Các mảnh vải lụa hoặc vải bông được nối, gấp, cuộn thành trang phục. Trang phục truyền thống của phụ nữ Thái Lan có 8 nhóm: Thai Chakkri, Thai Boromphiman, Thai Siwalai, Thai Chakkraphat, Thai Chitlada, Thai Ruean Ton, Thai Amarin và Thai Dusit. Trong đó có 3 loại phổ biến nhất được dùng cho tới tận bây giờ là Thai Chakkri, Thai Borompiman và Thai Siwalai.','Mỗi quốc gia đều có một trang phục truyền thống riêng, Việt Nam có áo dài, nhắc đến Hàn Quốc là nhớ tới hanbok, hay Nhật Bản nổi bật với kinono và Thái Lan cũng vậy.','https://shopxinh.com.vn/public/upload/images/my-nhan-hang-dau-thai-lan-dien-trang-phuc-truyen-thong-dep-nhu-nu-than.jpg',4,'Mỹ nhân hàng đầu Thái Lan diện trang phục truyền thống đẹp như nữ thần','Mỹ nhân hàng đầu Thái Lan diện trang phục truyền thống đẹp như nữ thần','Mỹ nhân hàng đầu Thái Lan diện trang phục truyền thống đẹp như nữ thần',NULL,'my-nhan-hang-dau-thai-lan-dien-trang-phuc-truyen-thong-dep-nhu-nu-than',1,'2019-08-20 21:37:03','2019-08-20 21:37:03');
/*!40000 ALTER TABLE `tbl_tintuc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_users`
--

DROP TABLE IF EXISTS `tbl_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `hinh` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `level` int(11) DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `tbl_users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_users`
--

LOCK TABLES `tbl_users` WRITE;
/*!40000 ALTER TABLE `tbl_users` DISABLE KEYS */;
INSERT INTO `tbl_users` (`id`, `name`, `email`, `email_verified_at`, `password`, `hinh`, `level`, `remember_token`, `created_at`, `updated_at`) VALUES (1,'Ivan Dương','dvnha0105@gmail.com',NULL,'$2y$10$gxSSpM31WukATtekQkk8XO..hN718G2IvCaUfoJIZ9Eb0l5ZAFGZy','https://scontent.fsgn5-7.fna.fbcdn.net/v/t1.0-9/997039_600307033414035_3365990301947089050_n.jpg?_nc_cat=101&_nc_oc=AQnCAJQ9j1dRsPu9na1o-pif5WVqo-k9YSGgM5g7d0FVBk3G-GO-UhAfh49sKY3MsZPnRdzYoeVMYsZhHdbO9VJZ&_nc_ht=scontent.fsgn5-7.fna&oh=9e1311a6c3fed8d922a404b8817370f7&oe=5DA26ED8',1,NULL,'2019-07-20 15:25:52','2019-07-20 15:25:52'),(4,'Dương Văn Nhã','duongnha0105@gmail.com',NULL,'$2y$10$MkzDDr.Z2i77m7myX7LYj.Na21YuKkyhG0I.HDDJPcd.Kae2IaqmW',NULL,NULL,NULL,'2019-08-25 13:56:32','2019-08-25 13:56:32');
/*!40000 ALTER TABLE `tbl_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'qaixcyxdhosting_shopx'
--

--
-- Dumping routines for database 'qaixcyxdhosting_shopx'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-09-02 11:15:08
