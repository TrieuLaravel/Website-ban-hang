<?php

namespace App\Model;
use Illuminate\Database\Eloquent\Model;

class PagesModel extends Model
{
    protected $guard = [];
    protected $table = 'pages';
}
