<?php

namespace App\Model\Frontend;

use Illuminate\Database\Eloquent\Model;

class SanphamModel extends Model
{
    protected $guard = [];
    protected $table = 'sanpham';
}
