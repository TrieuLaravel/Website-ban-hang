<?php

namespace App\Model\Frontend;

use Illuminate\Database\Eloquent\Model;

class PagesModel extends Model
{
    protected $guard = [];
    protected $table = 'pages';
}
