<?php

namespace App\Model\Frontend;

use Illuminate\Database\Eloquent\Model;

class KhachhangModel extends Model
{
    protected $guard = [];
    protected $table = 'khachhang';
}
