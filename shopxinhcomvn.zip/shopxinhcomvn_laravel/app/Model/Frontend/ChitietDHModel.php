<?php

namespace App\Model\Frontend;

use Illuminate\Database\Eloquent\Model;

class ChitietDHModel extends Model
{
    protected $guard = [];
    protected $table = 'chitietdonhang';
}
