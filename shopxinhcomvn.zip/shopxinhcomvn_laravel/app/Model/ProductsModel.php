<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class ProductsModel extends Model
{
    protected $guard = [];
    protected $table = 'sanpham';
}
