<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class OrdersModel extends Model
{
    protected $guard = [];
    protected $table = 'donhang';
    public $timestamps  = false;
}
