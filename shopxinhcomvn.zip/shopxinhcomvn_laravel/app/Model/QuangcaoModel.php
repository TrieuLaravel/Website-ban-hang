<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class QuangcaoModel extends Model
{
    protected $guard = [];
    protected $table = 'quangcao';
}
