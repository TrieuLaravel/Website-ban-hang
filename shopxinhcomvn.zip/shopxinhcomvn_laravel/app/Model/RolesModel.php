<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class RolesModel extends Model
{
    protected $guard = 'admin';
    protected $table ='roles';
}
