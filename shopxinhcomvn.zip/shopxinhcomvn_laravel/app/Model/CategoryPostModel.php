<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class CategoryPostModel extends Model
{
    protected $guard = [];
    protected $table ='nhomtin';
}
