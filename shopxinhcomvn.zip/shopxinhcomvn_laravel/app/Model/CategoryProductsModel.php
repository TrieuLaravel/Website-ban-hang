<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class CategoryProductsModel extends Model
{

    protected $table = 'loaisp';
}
