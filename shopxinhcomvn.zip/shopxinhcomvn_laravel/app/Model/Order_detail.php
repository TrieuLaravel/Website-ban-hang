<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Order_detail extends Model
{
    protected $guard = [];
    protected $table ='chitietdonhang';
}
