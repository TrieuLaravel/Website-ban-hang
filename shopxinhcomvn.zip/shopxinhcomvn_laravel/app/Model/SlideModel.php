<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class SlideModel extends Model
{
    protected $table = 'slide';

}
