<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class AnalyticsModel extends Model
{
    protected $guard = 'admin';
    protected $table = 'analytics';
}
