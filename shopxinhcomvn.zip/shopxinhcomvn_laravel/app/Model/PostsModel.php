<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class PostsModel extends Model
{
    protected $guard = [];
    protected $table = 'tintuc';
}
