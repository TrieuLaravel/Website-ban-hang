<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class NhacungcapModel extends Model
{
    protected $guard = [];
    protected $table = 'nhacungcap';
}
