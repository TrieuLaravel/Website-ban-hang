<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ValidateQuangcao extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name'=> 'required|min:5|max:32',
            'images'=>'required',
            'url'=>'required'
        ];
    }
    public function messages()
    {
        return [
            'name.required' =>'Tên quảng cáo không được để trống',
            'name.min' => 'Tên quảng cáo  phải có ít nhất 5 ký tự',
            'name.max' => 'Tên quảng cáo  không quá 32 ký tự',
            'images.required' => 'Hình quảng cáo là bắt buộc',
            'url.required' => 'Link không được để trống',
        ];
    }
}
