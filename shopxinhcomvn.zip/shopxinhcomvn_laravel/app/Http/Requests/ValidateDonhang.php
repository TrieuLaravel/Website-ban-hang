<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ValidateDonhang extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'ten_kh'=> 'required|min:5|max:32',
            'email_kh'=>'required|email|min:8|max:32',
            'dienthoai_kh'=>'required|min:10|max:12',
            'diachi_kh'=>'required|min:12|max:64',
            'type'=>'required',
            'note'=>'max:64'

        ];
    }
    public function messages()
    {
        return [
            'ten_kh.required' =>'Tên khách hàng không được để trống',
            'ten_kh.min' => 'Tên khách hàng phải có ít nhất 5 ký tự',
            'ten_kh.max' => 'Tên khách hàng không quá 32 ký tự',
            'email_kh.required' => 'Email không được để trống',
            'email_kh.email' => 'Email không đúng định dạng',
            'email_kh.min' => 'Email phải có ít nhất 8 ký tự',
            'email_kh.max' => 'Email tối đa 32 ký tự',
            'dienthoai_kh.required' => 'Điện thoại không được để trống',
            'dienthoai_kh.min' => 'Điện thoại phải có ít nhất 10 ký tự',
            'dienthoai_kh.max' => 'Điện thoại không quá 12 ký tự',
            'diachi_kh.required' => 'Địa chỉ không được để trống',
            'diachi_kh.min' => 'Địa chỉ phải có ít nhất 12 ký tự',
            'diachi_kh.max' => 'Địa chỉ không quá 64 ký tự',
            'type.required' => 'Phương thức thanh toán bắt buộc chọn',
            'note.max' => 'Ghi chú không quá 64 ký tự'
        ];
    }
}
