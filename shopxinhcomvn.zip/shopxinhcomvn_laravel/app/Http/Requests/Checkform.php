<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use App\Rules\testRules;
class Checkform extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name' => 'required|min:5|max:32',
            'username'=> 'required|min:5|max:32',
            'email'=> 'required|email|min:5|max:32',
            'password'=>'required|min:6|max:32'
        ];
    }
    public function messages()
    {
        return [
            'name.required' =>'Tên user không được để trống',
            'name.min' => 'Tên user phải có ít nhất 5 ký tự',
            'name.max' => 'Tên user không quá 32 ký tự',
            'username.required' =>'Tên đăng nhập không được để trống',
            'username.min' => 'Tên đăng nhập phải có ít nhất 5 ký tự',
            'username.max' => 'Tên đăng nhập không quá 32 ký tự',
            'email.min' => 'Email phải có ít nhất 5 ký tự',
            'email.max' => 'Email không quá 32 ký tự',
            'email.required' =>'Email không được để trống',
            'email.email' => 'Email không đúng định dạng',
            'password.required' => 'Mật khẩu không được để trống',
            'password.min' => 'Mật khẩu phải có ít nhất 6 ký tự',
            'password.max' => 'Mật khẩu không quá 32 ký tự'
        ];
    }
}
