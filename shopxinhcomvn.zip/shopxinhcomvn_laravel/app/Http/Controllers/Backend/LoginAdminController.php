<?php

namespace App\Http\Controllers\Backend;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use  App\Http\Requests\CheckValidate;
use Illuminate\Http\Request;
class LoginAdminController extends Controller
{
    function getLogin()
    {
        return view('backend.login.index');
    }

    function postLogin(CheckValidate $request)
    {
        // dd($request->all());
        //$request->validated();
        $user = ['username' => $request->username, 'password' => $request->password];
        if (Auth::guard('admin')->attempt($user))
        {
            // dd($request->all());
            return redirect()->route('admin.home');
        }
        else {
            return redirect()->route('admin.login')->with('msg','Đăng nhập không thành công. Bạn nhập lại user và password');
        }
    }
    function logoutAdmin()
    {
        Auth::guard('admin')->logout();
        session()->flush();
        return redirect()->route('admin.login');
    }
}
