<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\CategoryPostModel;
use DB;
class CategoryPostController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $title = "Danh sách nhóm tin";
        $ds = CategoryPostModel::where('trangthai','=','1')->get();//get->list, first()->1 row

        return view('backend.posts.category',['ds'=>$ds,'title'=>$title]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $data = [
            'title' => "Thêm nhóm tin",
            'method'=>'POST',
            'action'=>route('categoryposts.store')
        ];
        return view('backend.posts.themcategory',$data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $id = CategoryPostModel::insertGetId([
            'ten_nhomtin'=>$request->ten_nhomtin,
            'mota_nhomtin'=>$request->mota_nhomtin,
            'icon_nhomtin'=>$request->icon_nhomtin,
            'tieude_seo'=>$request->tieude_seo,
            'tukhoa_seo'=>$request->tukhoa_seo,
            'mota_seo'=>$request->mota_seo,
            'linkhinh_share'=>$request->linkhinh_share,
            'nhomtin_alias'=>$request->nhomtin_alias,
            'trangthai'=>$request->trangthai??'0',
        ]);
        return redirect(route('categoryposts.create'))->with('msg','Bạn đã thêm thành công nhóm tin có id = '.$id);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $loaitin = CategoryPostModel::where('ma_nhomtin','=',$id)->first();
        $data = [
           'title'=>'Sửa nhóm tin '.$id,
           'catenews'=>$loaitin,
            'method'=>'PUT',
            'action'=>route('categoryposts.update',$loaitin->ma_nhomtin)
       ];
       return view('backend.posts.themcategory',$data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        DB::table('nhomtin')->where('ma_nhomtin','=',$id)->update([
            'ten_nhomtin'=>$request->ten_nhomtin,
            'mota_nhomtin'=>$request->mota_nhomtin,
            'icon_nhomtin'=>$request->icon_nhomtin,
            'tieude_seo'=>$request->tieude_seo,
            'tukhoa_seo'=>$request->tukhoa_seo,
            'mota_seo'=>$request->mota_seo,
            'linkhinh_share'=>$request->linkhinh_share,
            'nhomtin_alias'=>$request->nhomtin_alias,
            'trangthai'=>$request->trangthai??'0',
        ]);
        return redirect(route('categoryposts.edit',$id))->with('msg','Cập nhật thành công nhóm tin');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $deleteCatePosts = CategoryPostModel::where('ma_nhomtin','=',$id);
        $deleteCatePosts->delete();
        return redirect(route('categoryposts.index'))->with('msg','Đã xóa thành công danh mục bài viết');
    }
}
