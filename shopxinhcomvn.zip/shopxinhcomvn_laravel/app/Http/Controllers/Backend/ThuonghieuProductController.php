<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\ThuonghieuModel;
use DB;
class ThuonghieuProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $title = "Danh sách thương hiệu sản phẩm";
        $ds = ThuonghieuModel::where('trangthai_thuonghieu','=','1')->get();//get->list, first()->1 row

        return view('backend.products.thuonghieu',['ds'=>$ds,'title'=>$title]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $data = [
            'title' => "Thêm thương hiệu sản phẩm",
            'method'=>'POST',
            'action'=>route('thuonghieu.store')
        ];
        return view('backend.products.themthuonghieu',$data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $id = ThuonghieuModel::insertGetId([
            'ten_thuonghieu'=>$request->ten_thuonghieu,
            'logo_thuonghieu'=>$request->logo_thuonghieu,
            'mota_thuonghieu'=>$request->mota_thuonghieu,
            'tieude_thuonghieu'=>$request->tieude_thuonghieu,
            'tukhoa_thuonghieu'=>$request->tukhoa_thuonghieu,
            'mota_seo_thuonghieu'=>$request->mota_seo_thuonghieu,
            'hinh_share_thuonghieu'=>$request->hinh_share_thuonghieu,
            'link_alias_thuonghieu'=>$request->link_alias_thuonghieu,
            'trangthai_thuonghieu'=>$request->trangthai_thuonghieu??'0',
        ]);
        return redirect(route('thuonghieu.create'))->with('msg','Bạn đã thêm thành công thương hiệu sản phẩm có id = '.$id);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $thuonghieu = ThuonghieuModel::where('ma_thuonghieu','=',$id)->first();
        $data = [
           'title'=>'Sửa thương hiệu sản phẩm '.$id,
           'brand'=>$thuonghieu,
            'method'=>'PUT',
            'action'=>route('thuonghieu.update',$thuonghieu->ma_thuonghieu)
       ];
       return view('backend.products.themthuonghieu',$data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        DB::table('thuonghieu')->where('ma_thuonghieu','=',$id)->update([
            'ten_thuonghieu'=>$request->ten_thuonghieu,
            'logo_thuonghieu'=>$request->logo_thuonghieu,
            'mota_thuonghieu'=>$request->mota_thuonghieu,
            'tieude_thuonghieu'=>$request->tieude_thuonghieu,
            'tukhoa_thuonghieu'=>$request->tukhoa_thuonghieu,
            'mota_seo_thuonghieu'=>$request->mota_seo_thuonghieu,
            'hinh_share_thuonghieu'=>$request->hinh_share_thuonghieu,
            'link_alias_thuonghieu'=>$request->link_alias_thuonghieu,
            'trangthai_thuonghieu'=>$request->trangthai_thuonghieu??'0',
        ]);
        return redirect(route('thuonghieu.edit',$id))->with('msg','Cập nhật thành công thương hiệu sản phẩm');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $deleteRow = ThuonghieuModel::where('ma_thuonghieu','=',$id);
        $deleteRow->delete();
        return redirect(route('thuonghieu.index'))->with('msg','Đã xóa thành công thương hiệu');
    }
}
