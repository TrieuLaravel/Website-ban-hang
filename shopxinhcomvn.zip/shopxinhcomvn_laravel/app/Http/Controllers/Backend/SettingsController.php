<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\SettingsModel;
use DateTimeZone;
use DB;
class SettingsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $title = "Cấu hình website";
        $ds = SettingsModel::get();//get->list, first()->1 row
        return view('backend.settings.index',['ds'=>$ds,'title'=>$title]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        // $data = [
        //     'title' => "Tùy chọn cấu hình",
        //     'method'=>'POST',
        //     'timezonelist' => DateTimeZone::listIdentifiers(DateTimeZone::ALL),
        //     'action'=>route('settings.store')
        // ];
        // return view('backend.settings.addsettings',$data);
        return redirect()->route('settings.index');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // SettingsModel::insertGetId([
        //     'logo'=>$request->logo,
        //     'title'=>$request->title,
        //     'keyword'=>$request->keyword,
        //     'descriptions'=>$request->descriptions,
        //     'hotline'=>$request->hotline,
        //     'timezone'=>$request->timezone,
        // ]);
        // return redirect(route('settings.create'))->with('msg','Bạn đã cài đặt cấu hình thành công');
        return redirect()->route('settings.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show()
    {
        return redirect()->route('settings.index');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $settings = where('id','=',$id)->first();
        $data = [
           'title'=>'Sửa Cấu hình',
           'settings'=>$settings,
           'timezonelist' => DateTimeZone::listIdentifiers(DateTimeZone::ALL),
            'method'=>'PUT',
            'action'=>route('settings.update',$settings->id)
       ];
        return view('backend.settings.addsettings',$data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        DB::table('setting')->where('id','=',$id)->update([
            'logo'=>$request->logo,
            'title'=>$request->title,
            'keyword'=>$request->keyword,
            'descriptions'=>$request->descriptions,
            'hotline'=>$request->hotline,
            'email'=>$request->email,
            'diachi'=>$request->diachi,
            'timezone'=>$request->timezone,
        ]);
        return redirect(route('settings.edit',$id))->with('msg','Cập nhật cấu hình thành công');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy()
    {
        return redirect()->route('settings.index');
    }
}
