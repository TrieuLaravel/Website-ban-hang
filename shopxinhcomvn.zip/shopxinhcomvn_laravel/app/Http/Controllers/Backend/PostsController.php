<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\CategoryPostModel;
use App\Model\PostsModel;
use DB;
class PostsController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $title = "Danh sách bài viết";
        $ds = PostsModel::where('trangthai','=','1')->get();//get->list, first()->1 row
        return view('backend.posts.index',['ds'=>$ds,'title'=>$title]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $data = [
            'title' => "Thêm mới tin tức",
            'dsloaitintuc'=>CategoryPostModel::where('trangthai','=','1')->get(),
            'method'=>'POST',
            'action'=>route('posts.store')
        ];
        return view('backend.posts.thempost',$data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $id = PostsModel::insertGetId([
            'ten_tintuc'=>$request->ten_tintuc,
            'noidung_tintuc'=>$request->noidung_tintuc,
            'tomtat_tintuc'=>$request->tomtat_tintuc,
            'hinh_thumbnail'=>$request->hinh_thumbnail,
            'ma_nhomtin'=>$request->ma_nhomtin,
            'tieudeseo_tintuc'=>$request->tieudeseo_tintuc,
            'tukhoaseo_tintuc'=>$request->tukhoaseo_tintuc,
            'motaseo_tintuc'=>$request->motaseo_tintuc,
            'hinhshare_tintuc'=>$request->hinhshare_tintuc,
            'link_alias_tintuc'=>$request->link_alias_tintuc,
            'trangthai'=>$request->trangthai??'0',
        ]);
        return redirect(route('posts.create'))->with('msg','Bạn đã thêm thành công tin tức có id = '.$id);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

        $news = PostsModel::where('ma_tintuc','=',$id)->first();
        $data = [
           'title'=>'Sửa tin tức '.$id,
           'news'=>$news,
           'dsloaitintuc'=>CategoryPostModel::where('trangthai','=','1')->get(),
            'method'=>'PUT',
            'action'=>route('posts.update',$news->ma_tintuc)
       ];
        return view('backend.posts.thempost',$data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        DB::table('tintuc')->where('ma_tintuc','=',$id)->update([
            'ten_tintuc'=>$request->ten_tintuc,
            'noidung_tintuc'=>$request->noidung_tintuc,
            'tomtat_tintuc'=>$request->tomtat_tintuc,
            'hinh_thumbnail'=>$request->hinh_thumbnail,
            'ma_nhomtin'=>$request->ma_nhomtin,
            'tieudeseo_tintuc'=>$request->tieudeseo_tintuc,
            'tukhoaseo_tintuc'=>$request->tukhoaseo_tintuc,
            'motaseo_tintuc'=>$request->motaseo_tintuc,
            'hinhshare_tintuc'=>$request->hinhshare_tintuc,
            'link_alias_tintuc'=>$request->link_alias_tintuc,
            'trangthai'=>$request->trangthai??'0',
        ]);
        return redirect(route('posts.edit',$id))->with('msg','Cập nhật thành công tin tức');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $deletePosts = PostsModel::where('ma_tintuc','=',$id);
        $deletePosts->delete();
        return redirect(route('posts.index'))->with('msg','Đã xóa thành công tin tức');
    }
}
