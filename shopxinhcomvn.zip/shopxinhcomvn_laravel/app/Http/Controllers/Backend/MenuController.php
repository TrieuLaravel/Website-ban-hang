<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\MenuModel;
use DB;
class MenuController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $title = 'Quản lý menu';
        $ds = MenuModel::where('status','!=','-1')->get();
        return view('backend.menu.index',compact('title','ds'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $data = [
            'title' => "Thêm mới menu",
            'method'=>'POST',
            'action'=>route('menu.store')
        ];
        return view('backend.menu.addmenu',$data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        MenuModel::insertGetId([
            'name'=>$request->name,
            'url'=>$request->url,
            'parent_id'=>$request->parent_id??'0',
            'locations'=>$request->locations??'0',
            'status'=>$request->status??'0',
        ]);
        return redirect()->route('menu.create')->with('msg','Bạn đã thêm thành công');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $menu = MenuModel::where('id',$id)->first();
        $data = [
           'title'=>'Sửa quảng cáo',
           'menu'=>$menu,
            'method'=>'PUT',
            'action'=>route('menu.update',$menu->id)
       ];
        return view('backend.menu.addmenu',$data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        DB::table('menu')->where('id','=',$id)->update([
            'name'=>$request->name,
            'url'=>$request->url,
            'parent_id'=>$request->parent_id??'0',
            'locations'=>$request->locations??'0',
            'status'=>$request->status??'0',
        ]);
        return redirect()->route('menu.edit',$id)->with('msg','Cập nhật thành công');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $deletemenu = MenuModel::where('id',$id);
        $deletemenu->delete();
        return redirect()->route('menu.index')->with('msg','Đã xóa thành công');
    }
}
