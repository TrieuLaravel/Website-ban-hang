<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\Checkform;
use App\Model\AdminLoginModel;
use App\Model\RolesModel;
class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $title = "Danh sách thành viên";
        $ds = AdminLoginModel::get();//get->list, first()->1 row
        return view('backend.user.index',['ds'=>$ds,'title'=>$title]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $data = [
            'title' => "Thêm thành viên mới",
            'dsquyen'=>RolesModel::where('status','=','1')->get(),
            'method'=>'POST',
            'action'=>route('user.store')
        ];
        return view('backend.user.themuser',$data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Checkform $request)
    {
        $request->validated();
        AdminLoginModel::insertGetId([
            'username' => $request->username,
            'name'=>$request->name,
            'email'=>$request->email,
            'password'=>bcrypt($request->password),
            'role_id'=>$request->role_id,
            'status'=>$request->status??'0',
        ]);
        return redirect(route('user.create'))->with('msg','Bạn đã thêm user thành công');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $user = AdminLoginModel::where('id','=',$id)->first();
        $data = [
           'title'=>'Sửa thông tin user '.$id,
           'user'=>$user,
           'dsquyen'=>RolesModel::where('status','=','1')->get(),
            'method'=>'PUT',
            'action'=>route('user.update',$user->id)
       ];
        return view('backend.user.themuser',$data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Checkform $request, $id)
    {
        $request->validated();
        AdminLoginModel::where('id','=',$id)->update([
            'username' => $request->username,
            'name'=>$request->name,
            'email'=>$request->email,
            'password'=>bcrypt($request->password),
            'role_id'=>$request->role_id,
            'status'=>$request->status??'0',
        ]);
        return redirect(route('user.edit',$id))->with('msg','Bạn đã cập nhật thông tin thành viên thành công');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $deletePosts = AdminLoginModel::where('id','=',$id);
        $deletePosts->delete();
        return redirect(route('user.index'))->with('msg','Đã xóa thành công user');
    }
}
