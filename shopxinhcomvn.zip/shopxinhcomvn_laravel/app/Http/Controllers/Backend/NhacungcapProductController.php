<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\NhacungcapModel;
use DB;
class NhacungcapProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $title = "Danh sách nhà cung cấp sản phẩm";
        $ds = NhacungcapModel::where('trangthai','=','1')->get();//get->list, first()->1 row

        return view('backend.products.nhacungcap',['ds'=>$ds,'title'=>$title]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $data = [
            'title' => "Thêm nhà cung cấp sản phẩm",
            'method'=>'POST',
            'action'=>route('nhacungcap.store')
        ];
        return view('backend.products.themnhacungcap',$data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $id = NhacungcapModel::insertGetId([
            'ten_ncc'=>$request->ten_ncc,
            'diachi_ncc'=>$request->diachi_ncc,
            'sodienthoai'=>$request->sodienthoai,
            'email'=>$request->email,
            'trangthai'=>$request->trangthai??'0',
        ]);
        return redirect(route('nhacungcap.create'))->with('msg','Bạn đã thêm thành công nhà cung cấp có id = '.$id);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $dsncc = NhacungcapModel::where('ma_ncc','=',$id)->first();
        $data = [
           'title'=>'Sửa loại sản phẩm '.$id,
           'ncc'=>$dsncc,
            'method'=>'PUT',
            'action'=>route('nhacungcap.update',$dsncc->ma_ncc)
       ];
       return view('backend.products.themnhacungcap',$data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        DB::table('nhacungcap')->where('ma_ncc','=',$id)->update([
            'ten_ncc'=>$request->ten_ncc,
            'diachi_ncc'=>$request->diachi_ncc,
            'sodienthoai'=>$request->sodienthoai,
            'email'=>$request->email,
            'trangthai'=>$request->trangthai??'0',
        ]);
        return redirect(route('nhacungcap.edit',$id))->with('msg','Cập nhật thành công nhà cung cấp');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $deleteNCC = NhacungcapModel::where('ma_ncc','=',$id);
        $deleteNCC->delete();
        return redirect(route('nhacungcap.index'))->with('msg','Đã xóa thành công nhà cung cấp');
    }
}
