<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\AnalyticsModel;
use DB;
class AnalyticsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $title = "Cấu hình Analytics và pixel website";
        $ds = AnalyticsModel::where('status','=','1')->get();//get->list, first()->1 row
        return view('backend.analytics.index',['ds'=>$ds,'title'=>$title]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $data = [
            'title' => "Thêm mã theo dõi",
            'method'=>'POST',
            'action'=>route('analytics.store')
        ];
        return view('backend.analytics.addanalytics',$data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        AnalyticsModel::insertGetId([
            'name'=>$request->name,
            'embeds'=>$request->embeds,
            'status'=>$request->status??0,
        ]);
        return redirect(route('analytics.create'))->with('msg','Bạn đã thêm mã theo dõi thành công');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $analytics = AnalyticsModel::where('id','=',$id)->first();
        $data = [
           'title'=>'Sửa mã theo dõi',
           'analytics'=>$analytics,
            'method'=>'PUT',
            'action'=>route('analytics.update',$analytics->id)
       ];
       return view('backend.analytics.addanalytics',$data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        DB::table('analytics')->where('id','=',$id)->update([
            'name'=>$request->name,
            'embeds'=>$request->embeds,
            'status'=>$request->status??0,
        ]);
        return redirect(route('analytics.edit',$id))->with('msg','Cập nhật mã theo dõi thành công');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $deletePosts = AnalyticsModel::where('id','=',$id);
        $deletePosts->delete();
        return redirect(route('analytics.index'))->with('msg','Đã xóa thành công mã theo dõi');
    }
}
