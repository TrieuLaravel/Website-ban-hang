<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\QuangcaoModel;
use App\Http\Requests\ValidateQuangcao;
class QuangcaoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $title = 'Danh sách banner quảng cáo';
        $ds = QuangcaoModel::where('status','1')->get();//get->list, first()->1 row
        return view('backend.quangcao.index',['ds'=>$ds,'title'=>$title]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $data = [
            'title' => "Tạo banner quảng cáo mới",
            'method'=>'POST',
            'action'=>route('quangcao.store')
        ];
        return view('backend.quangcao.addquangcao',$data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(ValidateQuangcao $request)
    {
        QuangcaoModel::insertGetId([
            'name'=>$request->name,
            'images'=>$request->images,
            'url'=>$request->url,
            'contentsads'=>$request->contentsads,
            'status'=>$request->status??'0',
        ]);
        return redirect()->route('quangcao.create')->with('msg','Bạn đã thêm thành công');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $quangcao = QuangcaoModel::where('id',$id)->first();
        $data = [
           'title'=>'Sửa quảng cáo',
           'quangcao'=>$quangcao,
            'method'=>'PUT',
            'action'=>route('quangcao.update',$quangcao->id)
       ];
        return view('backend.quangcao.addquangcao',$data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        DB::table('quangcao')->where('id','=',$id)->update([
            'name'=>$request->name,
            'images'=>$request->images,
            'url'=>$request->url,
            'contentsads'=>$request->contentsads,
            'status'=>$request->status??'0',
        ]);
        return redirect()->route('quangcao.edit',$id)->with('msg','Cập nhật thành công');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $deleteads = QuangcaoModel::where('id',$id);
        $deleteads->delete();
        return redirect()->route('quangcao.index')->with('msg','Đã xóa thành công');
    }
}
