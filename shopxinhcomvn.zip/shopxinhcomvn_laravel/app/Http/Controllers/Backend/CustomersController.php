<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\CustomersModel;
use DB;
class CustomersController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $title = "Danh sách khách hàng";
        $ds = CustomersModel::where('trangthai_kh','=','1')->orderBy('ma_kh', 'DESC')->get();//get->list, first()->1 row
        return view('backend.customers.index',['ds'=>$ds,'title'=>$title]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return redirect()->route('customers.index');
        // $data = [
        //     'title' => "Thêm mới khách hàng",
        //     'method'=>'POST',
        //     'action'=>route('customers.store')
        // ];
        // return view('backend.customers.themkh',$data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // $id = CustomersModel::insertGetId([
        //     'ten_kh'=>$request->ten_kh,
        //     'dienthoai_kh'=>$request->dienthoai_kh,
        //     'email_kh'=>$request->email_kh,
        //     'diachi_kh'=>$request->diachi_kh,
        //     'trangthai_kh'=>$request->trangthai_kh??'0',
        // ]);
        // return redirect(route('customers.create'))->with('msg','Bạn đã thêm thành công khách hàng có id = '.$id);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $dskh = CustomersModel::where('ma_kh','=',$id)->first();
        $data = [
           'title'=>'Sửa thông tin khách hàng có mã = '.$id,
           'dskh'=>$dskh,
            'method'=>'PUT',
            'action'=>route('customers.update',$dskh->ma_kh)
       ];
        return view('backend.customers.themkh',$data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        DB::table('khachhang')->where('ma_kh','=',$id)->update([
            'ten_kh'=>$request->ten_kh,
            'dienthoai_kh'=>$request->dienthoai_kh,
            'email_kh'=>$request->email_kh,
            'diachi_kh'=>$request->diachi_kh,
            'trangthai_kh'=>$request->trangthai_kh??'0',
        ]);
        return redirect(route('customers.edit',$id))->with('msg','Cập nhật thành công khách hàng');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $deleteCustomers = CustomersModel::where('ma_kh','=',$id);
        $deleteCustomers->delete();
        return redirect(route('customers.index'))->with('msg','Đã xóa thành công khách hàng');
    }
}
