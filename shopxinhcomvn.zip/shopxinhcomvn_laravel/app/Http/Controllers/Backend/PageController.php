<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\PagesModel;
class PageController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $title = "Danh sách các trang";
        $ds = PagesModel::where('status','=','1')->get();//get->list, first()->1 row

        return view('backend.pages.index',['ds'=>$ds,'title'=>$title]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $data = [
            'title' => "Thêm trang mới",
            'method'=>'POST',
            'action'=>route('pages.store')
        ];
        return view('backend.pages.create',$data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $id = PagesModel::insertGetId([
            'title'=>$request->title,
            'alias'=>$request->alias,
            'image'=>$request->image,
            'contents'=>$request->contents,
            'titleseo'=>$request->titleseo,
            'keyword'=>$request->keyword,
            'descriptions'=>$request->descriptions,
            'status'=>$request->status??'0',
        ]);
        return redirect(route('pages.create'))->with('msg','Bạn đã thêm thành công pages có id = '.$id);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show()
    {
        return view('backend.pages.index');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $pages = PagesModel::where('id','=',$id)->first();
        $data = [
           'title'=>'Sửa trang '.$id,
           'pages'=>$pages,
            'method'=>'PUT',
            'action'=>route('pages.update',$pages->id)
       ];
        return view('backend.pages.create',$data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        DB::table('pages')->where('id','=',$id)->update([
            'title'=>$request->title,
            'alias'=>$request->alias,
            'image'=>$request->image,
            'contents'=>$request->contents,
            'titleseo'=>$request->titleseo,
            'keyword'=>$request->keyword,
            'descriptions'=>$request->descriptions,
            'status'=>$request->status??'0',
        ]);
        return redirect(route('pages.edit',$id))->with('msg','Cập nhật thành công trang');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $deletePages = PagesModel::where('id','=',$id);
        $deletePages->delete();
        return redirect(route('pages.index'))->with('msg','Đã xóa thành công');
    }
}
