<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\RolesModel;
use DB;
class RolesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $title = "Danh sách quyền";
        $ds = RolesModel::where('status','=','1')->get();//get->list, first()->1 row
        return view('backend.roles.index',['ds'=>$ds,'title'=>$title]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $data = [
            'title' => "Thêm quyền",
            'method'=>'POST',
            'action'=>route('roles.store')
        ];
        return view('backend.roles.themroles',$data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        RolesModel::insertGetId([
            'name'=>$request->name,
            'description'=>$request->description,
            'status'=>$request->status??'0',
        ]);
        return redirect(route('roles.create'))->with('msg','Bạn đã thêm quyền thành công');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $roles =  DB::table('roles')->where('id','=',$id)->first();
        $data = [
            'title'=>'Sửa quyền '.$id,
            'roles'=>$roles,
            'method'=>'PUT',
            'action'=>route('roles.update',$roles->id)
        ];
        return view('backend.roles.themroles',$data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        RolesModel::where('id','=',$id)->update([
            'name'=>$request->name,
            'description'=>$request->description,
            'status'=>$request->status??'0',
        ]);
        return redirect(route('roles.edit',$id))->with('msg','Cập nhật thành công');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $deleteProduct =RolesModel::where('id','=',$id);
        $deleteProduct->delete();
        return redirect(route('roles.index'))->with('msg','Đã xóa thành công');
    }
}
