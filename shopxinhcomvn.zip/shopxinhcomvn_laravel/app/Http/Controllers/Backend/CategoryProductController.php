<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\CategoryProductsModel;
use DB;
class CategoryProductController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $title = "Danh sách loại sản phẩm";
        $ds = CategoryProductsModel::where('trangthai_loai_sp','=','1')->get();//get->list, first()->1 row

        return view('backend.products.category',['ds'=>$ds,'title'=>$title]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $data = [
            'title' => "Thêm danh mục sản phẩm",
            'method'=>'POST',
            'action'=>route('productcategory.store')
        ];
        return view('backend.products.themcategory',$data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $id = CategoryProductsModel::insertGetId([
            'ten_loai_sp'=>$request->ten_loai_sp,
            'mota_loai_sp'=>$request->mota_loai_sp,
            'hinh_loai_sp'=>$request->hinh_loai_sp,
            'ma_cha'=>$request->ma_cha,
            'tieude_loai_sp'=>$request->tieude_loai_sp,
            'tukhoa_loai_sp'=>$request->tukhoa_loai_sp,
            'mota_seo_loai_sp'=>$request->mota_seo_loai_sp,
            'hinh_share_loai_sp'=>$request->hinh_share_loai_sp,
            'link_alias_loai_sp'=>$request->link_alias_loai_sp,
            'trangthai_loai_sp'=>$request->trangthai_loai_sp??'0',
        ]);
        return redirect(route('productcategory.create'))->with('msg','Bạn đã thêm thành công loại sản phẩm có id = '.$id);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $loaisp = CategoryProductsModel::where('ma_loai','=',$id)->first();
        $data = [
           'title'=>'Sửa loại sản phẩm '.$id,
           'catepr'=>$loaisp,
            'method'=>'PUT',
            'action'=>route('productcategory.update',$loaisp->ma_loai)
       ];
       return view('backend.products.themcategory',$data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        DB::table('loaisp')->where('ma_loai',$id)->update([
            'ten_loai_sp'=>$request->ten_loai_sp,
            'mota_loai_sp'=>$request->mota_loai_sp,
            'hinh_loai_sp'=>$request->hinh_loai_sp,
            'ma_cha'=>$request->ma_cha,
            'tieude_loai_sp'=>$request->tieude_loai_sp,
            'tukhoa_loai_sp'=>$request->tukhoa_loai_sp,
            'mota_seo_loai_sp'=>$request->mota_seo_loai_sp,
            'hinh_share_loai_sp'=>$request->hinh_share_loai_sp,
            'link_alias_loai_sp'=>$request->link_alias_loai_sp,
            'trangthai_loai_sp'=>$request->trangthai_loai_sp??'0',
        ]);
        return redirect(route('productcategory.edit',$id))->with('msg','Cập nhật thành công loại sản phẩm');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $deleteCateProducts = CategoryProductsModel::where('ma_loai','=',$id);
        $deleteCateProducts->delete();
        return redirect(route('productcategory.index'))->with('msg','Đã xóa thành công loại sản phẩm');
    }

}
