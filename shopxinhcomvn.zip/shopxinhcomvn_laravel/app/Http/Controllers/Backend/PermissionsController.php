<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\PermissionsModel;
class PermissionsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $title = "Danh sách chức năng";
        $ds = PermissionsModel::where('status','=','1')->get();//get->list, first()->1 row
        return view('backend.permissions.index',['ds'=>$ds,'title'=>$title]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $data = [
            'title' => "Thêm chức năng",
            'method'=>'POST',
            'action'=>route('permissions.store')
        ];
        return view('backend.permissions.thempermissions',$data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        PermissionsModel::insertGetId([
            'name' => $request->name,
            'icon' => $request->icon,
            'url' => $request->url,
            'display_menu' => $request->display_menu??0,
            'display' => $request->display??0,
            'id_parent' => $request->id_parent,
            'status' => $request->status??0,
        ]);
        return redirect(route('permissions.create'))->with('msg','Bạn đã thêm chức năng thành công');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $permiss = PermissionsModel::where('id','=',$id)->first();
        $data = [
            'title'=>'Sửa chức năng '.$id,
            'permiss'=>$permiss,
            'method'=>'PUT',
            'action'=>route('permissions.update',$permiss->id)
        ];
        return view('backend.permissions.thempermissions',$data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        DB::table('permissions')->where('id','=',$id)->update([
            'name' => $request->name,
            'icon' => $request->icon,
            'url' => $request->url,
            'display_menu' => $request->display_menu??0,
            'display' => $request->display??0,
            'id_parent' => $request->id_parent,
            'status' => $request->status??0,
        ]);
        return redirect(route('permissions.edit',$id))->with('msg','Cập nhật thành công');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $deleteProduct =PermissionsModel::where('id','=',$id);
        $deleteProduct->delete();
        return redirect(route('roles.index'))->with('msg','Đã xóa thành công');
    }
}
