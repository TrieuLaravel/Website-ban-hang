<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DateTime;
use Hash;
use App\Model\NhacungcapModel;
use App\Model\ThuonghieuModel;
use App\Model\CategoryProductsModel;
use App\Model\ProductsModel;
use Illuminate\Support\Facades\Redirect;
use DB;

class ProductsController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $title = "Danh sách sản phẩm";
        $ds = ProductsModel::where('trangthai_sp','=','1')->get();//get->list, first()->1 row

        return view('backend.products.index',['ds'=>$ds,'title'=>$title]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $data = [
            'title' => "Thêm sản phẩm",
            'dsloaisp'=>CategoryProductsModel::where('trangthai_loai_sp','=','1')->get(),
            'dsnhacungcap'=>NhacungcapModel::where('trangthai','=','1')->get(),
            'dsthuonghieu'=>ThuonghieuModel::where('trangthai_thuonghieu','=','1')->get(),
            'method'=>'POST',
            'action'=>route('products.store')
        ];
        return view('backend.products.themsp',$data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $id = ProductsModel::insertGetId([
            'ma_sp'=>$request->ma_sp,
            'ten_sp'=>$request->ten_sp,
            'gia_sp'=>$request->gia_sp,
            'mota_sp'=>$request->mota_sp,
            'mota_chitiet'=>$request->mota_chitiet,
            'hinh_sp'=>$request->hinh_sp,
            'soluong_sp'=>$request->soluong_sp,
            'tieude_sp'=>$request->tieude_sp,
            'tukhoa_sp'=>$request->tukhoa_sp,
            'desc_sp'=>$request->desc_sp,
            'hinh_share'=>$request->hinh_share,
            'link_alias'=>$request->link_alias,
            'ma_ncc'=>$request->ma_ncc,
            'ma_loai'=>$request->ma_loai,
            'ma_thuonghieu'=>$request->ma_thuonghieu,
            'trangthai_sp'=>$request->trangthai_sp??'0',
        ]);
        return redirect(route('products.create'))->with('msg','Bạn đã thêm thành công sản phẩm có id = '.$id);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
       $sp = ProductsModel::where('ma','=',$id)->first();
       $data = [
           'title'=>'Sua san pham '.$id,
           'pr'=>$sp,
           'dsloaisp'=>CategoryProductsModel::where('trangthai_loai_sp','=','1')->get(),
            'dsnhacungcap'=>NhacungcapModel::where('trangthai','=','1')->get(),
            'dsthuonghieu'=>ThuonghieuModel::where('trangthai_thuonghieu','=','1')->get(),
            'method'=>'PUT',
            'action'=>route('products.update',$sp->ma)
       ];
       return view('backend.products.themsp',$data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        DB::table('sanpham')->where('ma','=',$id)->update([
            'ma_sp'=>$request->ma_sp,
            'ten_sp'=>$request->ten_sp,
            'gia_sp'=>$request->gia_sp,
            'mota_sp'=>$request->mota_sp,
            'mota_chitiet'=>$request->mota_chitiet,
            'hinh_sp'=>$request->hinh_sp,
            'soluong_sp'=>$request->soluong_sp,
            'tieude_sp'=>$request->tieude_sp,
            'tukhoa_sp'=>$request->tukhoa_sp,
            'desc_sp'=>$request->desc_sp,
            'hinh_share'=>$request->hinh_share,
            'link_alias'=>$request->link_alias,
            'ma_ncc'=>$request->ma_ncc,
            'ma_loai'=>$request->ma_loai,
            'ma_thuonghieu'=>$request->ma_thuonghieu,
            'trangthai_sp'=>$request->trangthai_sp??'0',
        ]);
        return redirect(route('products.edit',$id))->with('msg','Cập nhật thành công sản phẩm');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $deleteProduct = ProductsModel::where('ma','=',$id);
        $deleteProduct->delete();
        return redirect(route('products.index'))->with('msg','Đã xóa thành công sản phẩm');
    }

}
