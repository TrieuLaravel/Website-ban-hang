<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\OrdersModel;
use App\Model\CustomersModel;
use App\Model\Order_detail;
use App\Model\ProductsModel;
use DB;
class OrdersController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $title = "Danh sách đơn hàng";
        $ds = OrdersModel::orderBy('ma_dh','desc')->get();//get->list, first()->1 row
        return view('backend.orders.index',['ds'=>$ds,'title'=>$title]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return redirect()->route('orders.index');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $id = OrdersModel::insertGetId([
            'so_dh'=>$request->so_dh,
            'ma_kh'=>$request->ma_kh,
            'ngaydat'=>date('Y-m-d H:i:s'),
            'phi_vc_dh'=>$request->phi_vc_dh,
            'tongtien_dh'=>$request->tongtien_dh,
            'trangthai_dh'=>$request->trangthai_dh??'0',
            'type' => $request->type??'0',
            'note' => $request->note,
            'trangthai'=>$request->trangthai??'0',
            'ngay_tao' =>date('Y-m-d H:i:s'),
            'ngay_update' => date('Y-m-d H:i:s'),
        ]);
        return redirect(route('orders.create'))->with('msg','Bạn đã thêm thành công đơn hàng có id = '.$id);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //dd($id);
        $customerInfo = DB::table('khachhang')
                        ->join('donhang', 'khachhang.ma_kh', '=', 'donhang.ma_kh')
                        ->select('khachhang.*','donhang.*')
                        ->where('khachhang.trangthai_kh','!=','-1')->where('donhang.ma_dh',$id)
                        ->first();
        $billInfo = DB::table('donhang')
                    ->join('chitietdonhang', 'donhang.ma_dh', '=', 'chitietdonhang.ma_dh')
                    ->leftjoin('sanpham', 'chitietdonhang.ma_sp', '=', 'sanpham.ma')
                    ->leftjoin('khachhang','khachhang.ma_kh', '=', 'donhang.ma_kh')
                    ->select('donhang.*','sanpham.*','chitietdonhang.*')
                    ->where('donhang.ma_dh', '=', $id)->get();
        // dd($billInfo);
        return view('backend.orders.detailorder',compact('billInfo','customerInfo'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $orders = OrdersModel::where('ma_dh','=',$id)->first();
        $data = [
           'title'=>'Sửa đơn hàng '.$id,
           'orders'=>$orders,
           'dskh'=>CustomersModel::where('trangthai_kh','=','1')->get(),
            'method'=>'PUT',
            'action'=>route('orders.update',$orders->ma_dh)
       ];
        return view('backend.orders.editorders',$data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        DB::table('donhang')->where('ma_dh','=',$id)->update([
            'trangthai_dh'=>$request->trangthai_dh,
        ]);
        return redirect(route('orders.index'))->with('msg', "Cập nhật thành công đơn hàng");
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $deleteOrders = OrdersModel::where('ma_dh','=',$id);
        $deleteOrders->delete();
        return redirect(route('orders.index'))->with('msg','Đã xóa thành công đơn hàng');
    }
}