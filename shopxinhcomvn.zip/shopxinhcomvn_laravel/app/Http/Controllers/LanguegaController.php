<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class LanguegaController extends Controller
{
    var $langs = ['vi', 'en'];
	public function change($lang) {
		if (in_array($lang, $this->langs)) {
			session()->put('lang', $lang);
			return redirect()->back();
		}
	}
}
