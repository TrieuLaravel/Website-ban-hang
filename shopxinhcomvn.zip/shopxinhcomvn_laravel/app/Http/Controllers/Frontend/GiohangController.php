<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Frontend\SanphamModel;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Session;
class GiohangController extends Controller
{
    public function index()
    {
        return view('frontend.cart.cart');
    }
    private function createcart()
    {
        if (!session()->has('giohang')) {
            session()->put('giohang', []);
        }
        else {
            return redirect()->route('sanpham');
        }
    }
    public function addtocart($id)
    {
        $this->createcart();
        if ($id) {
            $gio = session()->get('giohang');
            $sp = SanphamModel::where('ma', $id)->first();
            if ($sp && $sp->trangthai_sp == 1 && $sp->soluong_sp > 0) {
                if (isset($gio[$sp->ma])) {
                    $gio[$sp->ma]['soluong']++;
                } else {
                    $gio[$sp->ma] = [
                        'ma' => $sp->ma,
                        'ten' => $sp->ten_sp,
                        'gia' => $sp->gia_sp,
                        'hinh' => $sp->hinh_sp,
                        'soluong' => 1,
                        'ngaytao'=>$sp->ngaytao,
                    ];
                }
                session()->put('giohang', $gio);
                $tongsl=$tongtien=0;
                foreach(session()->get('giohang') as $item)
                {
                    $tongsl += $item['soluong'];
                    $tongtien += $item['gia']*$item['soluong'];
                }
                $data = [
                    'soluong'=>$tongsl,
                    'tongtien'=>$tongtien
                ];
                return response()->json($data, 200);
            } else {
                return  redirect()->route('sanpham');
            }
        } else {
            return redirect()->route('sanpham');
        }
    }
    public function upadtecart(Request $rq)
    {
        if (is_array($rq->soluong)) {
            $gio = session()->get('giohang');
            foreach ($rq->soluong as $ma => $sl) {
                $gio[$ma]['soluong'] = $sl;
            }
            session()->put('giohang', $gio);
            return  redirect()->route('giohang')->with('msg', 'Cập nhật giỏ hàng thành công');
        } else
            return  redirect()->route('giohang')->with('msg', 'Cập nhật thất bại');
    }
    public function capnhat()
    {
        
    }
    public function delfromcart($id)
    {
        if ($id) {
            $gio = session()->get('giohang');
            unset($gio[$id]);
            session()->put('giohang', $gio);
            return  redirect()->route('giohang')->with('msg', 'Xoa thanh cong');
        } else
            return  redirect()->route('giohang');
    }

}
