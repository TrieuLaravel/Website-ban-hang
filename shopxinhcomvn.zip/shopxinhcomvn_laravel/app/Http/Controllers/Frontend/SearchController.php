<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Frontend\SanphamModel;
class SearchController extends Controller
{
    public function index(Request $rq)
    {
        $product = SanphamModel::where('ten_sp','like','%'.$rq->key.'%')
                                ->orWhere('gia_sp',$rq->key)
                                ->get();
        return view('frontend.search',compact('product'));
    }
}
