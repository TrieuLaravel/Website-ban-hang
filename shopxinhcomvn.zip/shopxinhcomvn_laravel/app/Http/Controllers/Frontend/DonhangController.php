<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\OrdersModel;
use App\Model\Frontend\KhachhangModel;
use App\Model\Frontend\ChitietDHModel;
use App\Http\Requests\ValidateDonhang;
use DB;
use Illuminate\Support\Facades\Mail;
class DonhangController extends Controller
{
    public function index()
    {
        return view('frontend.cart.checkout');
    }
    public function store(ValidateDonhang $rq)
    {
        // dd($rq->all());
        $sodh = time();
        $data = [
            'ten_kh' => $rq->ten_kh,
            'email_kh' => $rq->email_kh,
            'dienthoai_kh' => $rq->dienthoai_kh,
            'diachi_kh' => $rq->diachi_kh,
            'trangthai_kh'=>1,
            'ngaytao_kh'=>date('Y-m-d H:i:s'),
            'ngay_update_kh'=>date('Y-m-d H:i:s'),
        ];
        $idkh = KhachhangModel::insertGetId($data);
        $order_data = [
            'ma_kh' => $idkh,
            'ngaydat' => date('Y-m-d H:i:s'),
            'so_dh' => $sodh,
            'phi_vc_dh' => 0,
            'tongtien_dh'=>0,
            'trangthai_dh'=>0,
            'type' =>$rq->type??'0',
            'note' => $rq->note,
            'trangthai'=>1,
            'ngay_tao'=>date('Y-m-d H:i:s'),
            'ngay_update'=>date('Y-m-d H:i:s')
        ];
        $order = OrdersModel::insertGetId($order_data);
        $gio =session()->get('giohang');
        $tong = 0;
        foreach($gio as $ma=>$sp)
        {
            $tt =$sp['soluong'] * $sp['gia'];
            $tong += $tt;
            $chitiet = [
                'ma_dh'=>$order,
                'ma_sp'=>$ma,
                'soluong'=>$sp['soluong'],
                'dongia'=>$sp['gia'],
                'trangthai'=>1,
                'ngaytao'=>date('Y-m-d H:i:s'),
                'ngay_update'=>date('Y-m-d H:i:s')
            ];
            ChitietDHModel::insert($chitiet);
        }
        OrdersModel::where('ma_dh',$order)->update(['tongtien_dh'=>$tong]);
        session()->flush();
        ChitietDHModel::where('ma_dh',$order);
        // Mail::send('frontend.cart.sendmaildonhang', ['order'=>$order,'sodh'=>$sodh], function ($message) use ($rq,$sodh) {
        //     $message->from('noustore1810@gmail.com', 'Nou Store - Hệ thống cửa hàng thời trang online');
        //     $message->to($rq->email_kh, $rq->ten_kh);
        //     $message->subject('Xác nhận thông tin đơn hàng có mã đơn hàng ', $sodh);
        // });
        return  redirect()->route('done',$sodh);
    }
    function done($sodh)
    {
        $customerInfo = DB::table('khachhang')
                    ->join('donhang', 'khachhang.ma_kh', '=', 'donhang.ma_kh')
                    ->select('khachhang.*','donhang.*')
                    ->where('khachhang.trangthai_kh','!=','-1')->where('donhang.so_dh',$sodh)
                    ->first();
        $billInfo = DB::table('donhang')
                    ->join('chitietdonhang', 'donhang.ma_dh', '=', 'chitietdonhang.ma_dh')
                    ->leftjoin('sanpham', 'chitietdonhang.ma_sp', '=', 'sanpham.ma')
                    ->leftjoin('khachhang','khachhang.ma_kh', '=', 'donhang.ma_kh')
                    ->select('donhang.*','sanpham.*','chitietdonhang.*')
                    ->where('donhang.so_dh', '=', $sodh)->get();
        // dd($billInfo);
        return view('frontend.cart.done',compact('billInfo','customerInfo'));
    }
}
