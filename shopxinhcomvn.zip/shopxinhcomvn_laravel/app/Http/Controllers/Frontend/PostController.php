<?php

namespace App\Http\Controllers\Frontend;
use Illuminate\Support\Facades\URL;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\PostsModel;
class PostController extends Controller
{
    public function index()
    {
        $title = 'Tin tức';
        $ds =PostsModel::where('trangthai','1')->paginate(5);
        return view('frontend.posts.index',compact('title','ds'));
    }
    public function getnhomtin(Request $rq)
    {
        $postItem = PostsModel::where('ma_nhomtin',$rq->id)->paginate(5);
        return view('frontend.posts.category_post',compact('postItem'));
    }
    public function getSingleNews(Request $rq)
    {
        $post = PostsModel::where('ma_tintuc',$rq->id)->where('trangthai','1')->first();
        return view('frontend.posts.detail_post',compact('post'));
    }
}
