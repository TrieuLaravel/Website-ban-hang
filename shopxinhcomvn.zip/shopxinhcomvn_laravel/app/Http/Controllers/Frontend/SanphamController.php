<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Frontend\SanphamModel;
use DB;
class SanphamController extends Controller
{
    public function index()
    {
        $title = 'Danh sách sản phẩm';
        $ds =SanphamModel::where('trangthai_sp','1')->paginate(8);
        return view('frontend.products.index', ['ds'=>$ds,'title'=>$title]);
    }
    public function singleproduct(Request $rq)
    {
        $sanpham_ct = SanphamModel::where('ma',$rq->id)->where('trangthai_sp','1')->first();
        $sp_tuongtu = SanphamModel::where('ma_loai',$sanpham_ct->ma_loai)->paginate(3);
        return view('frontend.products.detail_sanpham',compact('sanpham_ct','sp_tuongtu'));
    }

}
