<?php

namespace App\Http\Controllers\Frontend;
use Illuminate\Support\Facades\URL;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\ProductsModel;
use App\Model\CategoryProductsModel;
class CategoryProducts extends Controller
{

    public function getLoaisanpham(Request $rq)
    {
        $sp_theoloai = ProductsModel::where('ma_loai',$rq->id)->get();
        $loaisp = CategoryProductsModel::where('trangthai_loai_sp','1')->get();
        return view('frontend.products.loai_sanpham',compact('sp_theoloai','loaisp'));
    }
}
