<?php

namespace App\Http\Controllers\Frontend;
use Illuminate\Support\Facades\URL;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\SlideModel;
use App\Model\SettingsModel;
use App\Model\AnalyticsModel;
use App\Model\CategoryPostModel;
use App\Model\PostsModel;
use App\Model\CategoryProductsModel;
use App\Model\Frontend\SanphamModel;
use App\Http\Requests\CheckContacts;
use App\Model\Frontend\PagesModel;
use Mail;
class HomeController extends Controller
{
    public function getIndex()
    {
        $settings = SettingsModel::all();
        $analytics = AnalyticsModel::all();
        $slide = SlideModel::all();
        $loai_sp = CategoryProductsModel::all();
        $sanpham = SanphamModel::all()->take(8);
        $tintuc = PostsModel::all()->take(4);
        return view('frontend.pages.index',compact('slide','settings','analytics','sanpham','tintuc'));
    }
    public function getAbouts()
    {
        $title = 'Trang giới thiệu';
        $pages = PagesModel::where('status','1')->where('id','1')->get();
        return view('frontend.pages.abouts',compact('pages','title'));
    }
    public function getContacts()
    {
        return view('frontend.pages.contacts');
    }

    public function postContacts(CheckContacts $rq)
    {
        Mail::raw($rq->message, function ($message)  use ($rq) {
            $message->from($rq->email, $rq->name);
            $message->to('noustore1810@gmail.com', 'Nou Store');
            $message->subject('Thư liên hệ');
        });
        return redirect()->route('guilienhe')->with('message', 'Cảm ơn bạn đã gửi thông tin liên hệ cho chúng tôi');
    }
    // public function getCategoryProduct()
    // {
    //     return view('frontend.products.loai_sanpham');
    // }
    // public function getCategoryNews()
    // {
    //     return view('frontend.posts.category_post');
    // }
    // public function getSingleNews()
    // {
    //     return view('frontend.posts.detail_post');
    // }
    // public function getCheckout()
    // {
    //     return view('frontend.cart.checkout');
    // }
}
