<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use App\Model\CategoryProductsModel;
use App\Model\CategoryPostModel;
use App\Model\QuangcaoModel;
use App\Model\SettingsModel;
use Symfony\Component\HttpFoundation\Session\Session;
use PhpParser\Node\Expr\New_;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        view()->composer('*',function($view){
            $loai_sp = CategoryProductsModel::all();
            $category_news = CategoryPostModel::all();
            $quangcao = QuangcaoModel::all();
            $settings = SettingsModel::all();
            $view->with(compact('loai_sp','category_news','quangcao','settings'));
        });
    }
}
