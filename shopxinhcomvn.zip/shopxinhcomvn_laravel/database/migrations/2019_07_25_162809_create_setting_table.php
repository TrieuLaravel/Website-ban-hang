<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSettingTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('setting', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->longText('logo');
            $table->string('title');
            $table->string('keyword');
            $table->longText('descriptions');
            $table->string('hotline');
            $table->string('timezone');
            $table->timestamps();
        });
        Schema::create('langues', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('name');
            $table->string('icon');
            $table->string('url');
            $table->integer('status');
            $table->timestamps();
        });
        Schema::create('analytics', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('name');
            $table->longText('embeds');
            $table->integer('status');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('setting');
    }
}
