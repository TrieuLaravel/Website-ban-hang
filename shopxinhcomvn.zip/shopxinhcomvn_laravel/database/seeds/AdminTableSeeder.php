<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class AdminTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // DB::table('admin')->truncate();
        App\Model\AdminLoginModel::create([
                'username' => 'Admin',
                'name' => 'Ivan Dương',
                'email' => 'dvnha0105@gmail.com',
                'password' => bcrypt('123456'),
                'role_id'  => 1,
            ]
        );
    }
}
